 /* 
 
 Fixlet Compliance by Content report
 
 Created by Lee Wei
 Last updated December 3rd, 2015
 Version 1.2

 See BigFix forum post for additional information
 https://forum.bigfix.com/t/report-available-fixlet-compliance-by-content/6176
 
*/ 

Ext.BLANK_IMAGE_URL = '/ext-3.2.0/resources/images/default/s.gif';

Ext.onReady(function () {

    Ext.QuickTips.init();

    var cp = new Ext.state.CookieProvider({
        path: "/",
        expires: new Date(new Date().getTime() + (1000 * 60 * 60 * 24 * 180)) // 180 days
    });

    Ext.state.Manager.setProvider(cp);

    var myChartData = [];
    var totalComputersPatched = 0;
    var totalComputersOutstanding = 0;
    var totalComputers = 0;
	var totalFixlets = 0;
    var compliancePercentage = 0;
    var complianceHTML = '';
    var complianceLegendHTML = '';
    var customFixletText = 'Session Relevance returning Fixlets';
    var customComputerText = 'Session Relevance returning Computers';
	var startTimeReport;
	var endTimeReport;
	
	var win;  // Message window

	var comboFromArray1;
	var comboFromArray2;
	
	var chartPrefDefault = 'Chart Fixlets by Most Outstanding';
	
	// How to treat Fixlets with no computers applicable. Values should be 0, 100, or -99 for not applicable
	var valueForZeroApplicable = -99; 
	
    // Data for Chart preference
    var chartPreference = new Ext.data.ArrayStore({
        fields: ['choice'],
        data : [[chartPrefDefault], ['Chart Fixlets by Most Installed']]
    });

    // Filter Panel ------------------------------------------------------------------------------------------------------------------------------------------------------
    var FiltersPanel = new Ext.Panel({
        iconCls: 'icon-filter',
        title: 'Filters (v1.2)',
        renderTo: 'filters',
        width: 1000,
        layout: 'absolute',
        collapsible: true,
        bodyStyle: {
            background: '#cedff5',
            padding: '10px'
        },
        html: 
			'<table><tr>' + 
				'<td><div class="lw-label">Content:&nbsp;</div></td>' + 
				'<td><div id="baselineDiv"><input class="lw-combo" type="text" id="baseline" size="40" /></div></td>' + 
				'<td><div class="lw-label" style="margin-left: 10px">Computer&nbsp;Group:&nbsp;</div></td>' + 
				'<td><div><input class="lw-combo" type="text" id="computerGroup" size="40"/></div></td>' + 
			'</tr>' + '<tr>' + 
				'<td></td>' + 
				'<td style="vertical-align:top;"><div id="customFixletDiv"></div></td>' + 
				'<td></td>' + 
				'<td style="vertical-align:top;"><div id="customComputerDiv" ></div></td>' + 
			'</tr>' + 
			'</table>',        
		tbar: new Ext.Toolbar({
            items: [{
                xtype: 'tbfill'
            },			
            {
                xtype: 'tbseparator'
            },
			{
				xtype: 'tbbutton',
				iconCls: 'icon-generate',
				text: 'Generate Report',
				scale: 'small',
				handler: function(){
				
					if (Ext.isEmpty(comboFromArray1.value) || (comboFromArray1.value.substring(0, 1) == 'X' && comboFromArray1.value.split(',').length == 1)) {
						// if (Ext.isEmpty(comboFromArray1.value)) {
						Ext.Msg.show({
							title: 'Warning',
							msg: 'Please select content',
							buttons: Ext.Msg.OK,
							icon: Ext.MessageBox.WARNING,
							minWidth: 300
						});
						return;
					}
					else 
						if (Ext.isEmpty(comboFromArray2.value)) {
							Ext.Msg.show({
								title: 'Warning',
								msg: 'Please select a computer group',
								buttons: Ext.Msg.OK,
								icon: Ext.MessageBox.WARNING,
								minWidth: 300
							});
							return;
						}
					
					// Save info as cookies			
					cp.set('lw-cb-fixlet', comboFromArray1.getValue());
					cp.set('lw-cb-computer', comboFromArray2.getValue());
					cp.set('lw-msgroup-checkbox', document.getElementById('GroupMSPatches').checked);
					cp.set('lw-chartpref', Ext.getCmp('ChartByOutstandingOrPatched').getValue());
					
					if (comboFromArray1.getValue() == 'R||Custom Relevance Expression||0') {
						cp.set('lw-custom-fixlet', textAreaFixlet.getValue());
					}
					
					if (comboFromArray2.getValue() == 'Custom Relevance Expression (0)') {
						cp.set('lw-custom-computer', textAreaComputer.getValue());
					}
					
					info('Running report, please wait...', 1000, 'filters', 100);
					
					var task = {
						run: function(){
							startTimeReport = new Date().getTime();
						
							buildGrid();
							buildChart();
							endTimeReport = new Date().getTime();
							
							var CurrentTime = new Date();
							document.getElementById('TimeStampDiv').innerHTML = '<br>Generated on: ' +  CurrentTime.format('M jS, Y g:iA T') +
								'  <br>Elapsed time for report: ' + ((endTimeReport-startTimeReport)/1000)       + ' seconds.';
						},
						interval: 50,
						repeat: 1
					};
					
					Ext.TaskMgr.start(task);
				}
			},  // Button
            {
                xtype: 'tbseparator'
            },
			{
			    xtype: 'checkbox',
			    fieldLabel: 'Label',
			    boxLabel: 'Group MS Patches',
			    name: 'GroupMSPatches',
			    checked: true,
			    id: 'GroupMSPatches'
			},
            {
                xtype: 'tbseparator'
            },
			{
			    xtype: 'combo',
			    fieldLabel: 'Label',
				editable: false,
				width: 200,
				displayField: 'choice',
				store: chartPreference,
			    id: 'ChartByOutstandingOrPatched',
				name: 'ChartByOutstandingOrPatched',
				value: chartPrefDefault,
				mode: 'local',
		        forceSelection: true,
        		triggerAction: 'all',
        		selectOnFocus:true
			},
            {
                xtype: 'tbseparator'
            },
			{
				xtype: 'tbbutton',
				iconCls: 'icon-script-edit',
				text: 'Edit Custom Relevance',
				tooltip: '<b>Show or Hide Relevance text box</b><br/>The relevances entered are used by the selection Custom Session Relevance in the filter list',
				scale: 'small',
				handler: function(){
		            var divCustomFixlet = document.getElementById('customFixletDiv');
		            var divCustomComputer = document.getElementById('customComputerDiv');
		
		            if (this.getText() == 'Edit Custom Relevance') {
						this.setText('Hide Custom Relevance');
		                divCustomFixlet.style.display = 'block';
		                textAreaFixlet.setValue(customFixletText);
		
		                divCustomComputer.style.display = 'block';
		                textAreaComputer.setValue(customComputerText);
		            } else {
						this.setText('Edit Custom Relevance');
		                customFixletText = textAreaFixlet.getValue();
		                divCustomFixlet.style.display = 'none';
		
		                customComputerText = textAreaComputer.getValue();
		                divCustomComputer.style.display = 'none';
		            }	
				}
            },
            {
                xtype: 'tbseparator'
            }]
		})
    });
			
    var textAreaFixlet = new Ext.form.TextArea({
        id: 'lw-combo',
        // width: 242,
		width: 400,
        // height: 100,
        grow: true,
        growMax: 200,
        renderTo: 'customFixletDiv'
    });

    var textAreaComputer = new Ext.form.TextArea({
        // width: 242,
		width: 400,
        // height: 100,
        grow: true,
        growMax: 200,
        renderTo: 'customComputerDiv'
    });
	
    document.getElementById('customFixletDiv').style.display = 'none';
    document.getElementById('customComputerDiv').style.display = 'none';

    var currentDay = new Date();
    var oneMonthAgo = new Date().add('mo', -1);
    var twoMonthsAgo = new Date().add('mo', -2);

    var patchTuesdayCurrent = setPeriods(currentDay, 'Begin');
    var patchTuesdayCurrentEnd;
    var patchTuesdayPrevious;
    var patchTuesdayPreviousEnd;
    var patchTuesdayPrevious2;
    var patchTuesdayPrevious2End;

    if (patchTuesdayCurrent > currentDay) {
        currentDay = new Date().add('mo', -1);
        oneMonthAgo = new Date().add('mo', -2);
        twoMonthsAgo = new Date().add('mo', -3);
    }

    patchTuesdayCurrent = setPeriods(currentDay, 'Begin');
    patchTuesdayCurrentEnd = setPeriods(currentDay, 'End');
    patchTuesdayPrevious = setPeriods(oneMonthAgo, 'Begin');
    patchTuesdayPreviousEnd = setPeriods(oneMonthAgo, 'End');
    patchTuesdayPrevious2 = setPeriods(twoMonthsAgo, 'Begin');
    patchTuesdayPrevious2End = setPeriods(twoMonthsAgo, 'End');

    patchTuesdayCurrent = patchTuesdayCurrent.format('d M Y');
    patchTuesdayCurrentEnd = patchTuesdayCurrentEnd.format('d M Y');
    patchTuesdayPrevious = patchTuesdayPrevious.format('d M Y');
    patchTuesdayPreviousEnd = patchTuesdayPreviousEnd.format('d M Y');
    patchTuesdayPrevious2 = patchTuesdayPrevious2.format('d M Y');
    patchTuesdayPrevious2End = patchTuesdayPrevious2End.format('d M Y');

    // Baseline DropList (ComboBox) --------------------------------------------------------------------------------------------------------------------------------------
	
	// Added by Mark Macherey
	// http://forum.bigfix.com/viewtopic.php?id=5393
	var rel1 = '("C||All Microsoft Critical Fixlets||" & it as string) of number of (bes fixlets whose (fixlet flag of it = true and display name of site of it starts with "Patches for Windows" and source severity of it as lowercase = "critical" and name of it as lowercase does not contain "corrupt patch" and name of it as lowercase does not contain "superseded")); ("I||All Microsoft Important Fixlets||" & it as string) of number of (bes fixlets whose (fixlet flag of it = true and display name of site of it starts with "Patches for Windows" and source severity of it as lowercase = "important" and name of it as lowercase does not contain "corrupt patch" and name of it as lowercase does not contain "superseded")); ("M||All Microsoft Moderate Fixlets||" & it as string) of number of (bes fixlets whose (fixlet flag of it = true and display name of site of it starts with "Patches for Windows" and source severity of it as lowercase = "moderate" and name of it as lowercase does not contain "corrupt patch" and name of it as lowercase does not contain "superseded")); ("L||All Microsoft Low Fixlets||" & it as string) of number of (bes fixlets whose (fixlet flag of it = true and display name of site of it starts with "Patches for Windows" and source severity of it as lowercase = "low" and name of it as lowercase does not contain "corrupt patch" and name of it as lowercase does not contain "superseded")); ("N||All Microsoft None Fixlets||" & it as string) of number of (bes fixlets whose (fixlet flag of it = true and display name of site of it starts with "Patches for Windows" and source severity of it as lowercase = "none" and name of it as lowercase does not contain "corrupt patch" and name of it as lowercase does not contain "superseded")); ("U||All Microsoft Unspecified Fixlets||" & it as string) of number of (bes fixlets whose (fixlet flag of it = true and display name of site of it starts with "Patches for Windows" and source severity of it as lowercase = "<unspecified>" and name of it as lowercase does not contain "corrupt patch" and name of it as lowercase does not contain "superseded")); ("A||Microsoft Patches (Current Period - ' + patchTuesdayCurrent + ')||" & it as string) of number of (bes fixlets whose (fixlet flag of it = true and display name of site of it starts with "Patches for Windows" and name of it as lowercase does not contain "corrupt patch" and name of it as lowercase does not contain "superseded" and source release date of it >= date "' + patchTuesdayCurrent + '" and source release date of it <= date "' + patchTuesdayCurrentEnd + '")); ("D||Microsoft Patches (Previous Period - ' + patchTuesdayPrevious + ')||" & it as string) of number of (bes fixlets whose (fixlet flag of it = true and display name of site of it starts with "Patches for Windows" and name of it as lowercase does not contain "corrupt patch" and name of it as lowercase does not contain "superseded" and source release date of it >= date "' + patchTuesdayPrevious + '" and source release date of it <= date "' + patchTuesdayPreviousEnd + '")); ("E||Microsoft Patches (Previous Period - ' + patchTuesdayPrevious2 + ')||" & it as string) of number of (bes fixlets whose (fixlet flag of it = true and display name of site of it starts with "Patches for Windows" and name of it as lowercase does not contain "corrupt patch" and name of it as lowercase does not contain "superseded" and source release date of it >= date "' + patchTuesdayPrevious2 + '" and source release date of it <= date "' + patchTuesdayPrevious2End + '")); "X||-- Baselines --||0"; unique values of ("B||" & name of it & "||" & number of components of component groups of it as string) of bes fixlets whose (baseline flag of it = true);"X||-- Sites --||0"; ("S||" & it & "||" & multiplicity of it as string) of unique values of display names of sites of bes fixlets whose (fixlet flag of it = true);"X||-- Relevance Expression --||0"; "R||Custom Relevance Expression||0" ';

    var res1 = EvaluateRelevance(rel1);
    var contentArray = [];

    for (var i = 0; i < res1.length; i++) {
        var OneRowArray = [];
        OneRowArray = res1[i].split('||');
        // The next if-else statements take care of "label" such as -- Baseline -- 
        // They don't have content count
        if (OneRowArray[0] == 'X') {
            OneRowArray[3] = OneRowArray[1];
            OneRowArray[4] = res1[i];
        } else {
            OneRowArray[3] = OneRowArray[1] + ' (' + OneRowArray[2] + ')';
            OneRowArray[4] = res1[i];
        }
        contentArray[i] = OneRowArray;
    }

    var storeContent = new Ext.data.ArrayStore({
        fields: ['type', 'name', 'count', 'display', 'full'],
        data: contentArray
    });

    Date.prototype.add = function (sInterval, iNum) {
        var dTemp = this;
        if (!sInterval || iNum == 0) {
            return dTemp;
        }
        switch (sInterval.toLowerCase()) {
        case "ms":
            dTemp.setMilliseconds(dTemp.getMilliseconds() + iNum);
            break;
        case "s":
            dTemp.setSeconds(dTemp.getSeconds() + iNum);
            break;
        case "mi":
            dTemp.setMinutes(dTemp.getMinutes() + iNum);
            break;
        case "h":
            dTemp.setHours(dTemp.getHours() + iNum);
            break;
        case "d":
            dTemp.setDate(dTemp.getDate() + iNum);
            break;
        case "mo":
            dTemp.setMonth(dTemp.getMonth() + iNum);
            break;
        case "y":
            dTemp.setFullYear(dTemp.getFullYear() + iNum);
            break;
        }
        return dTemp;
    };

    function setPeriods(workingDay, choice) {
        if (choice == 'Begin') {
            var today = workingDay;
            var firstOfMonth = new Date(today.getFullYear(), today.getMonth(), 1);
            var firstOfMonthSaved = new Date(today.getFullYear(), today.getMonth(), 1);
            var firstTuesday = firstOfMonth.add('d', (2 - firstOfMonth.getDay()));
            var secondTuesday;

            if (firstTuesday.getTime() < firstOfMonthSaved.getTime()) {
                secondTuesday = firstTuesday.add('d', 14);
            } else {
                secondTuesday = firstTuesday.add('d', 7);
            }
            return secondTuesday;
        }

        if (choice == 'End') {
            var nextMonthToday = workingDay.add('mo', 1);
            var firstOfNextMonth = new Date(nextMonthToday.getFullYear(), nextMonthToday.getMonth(), 1);
            var firstOfNextMonthSaved = new Date(nextMonthToday.getFullYear(), nextMonthToday.getMonth(), 1);
            var firstMondayNextMonth = firstOfNextMonth.add('d', (1 - firstOfNextMonth.getDay()));
            var secondMonday;

            var tempMonday = firstOfNextMonth.add('d', (1 - firstOfNextMonth.getDay()));
            if ((tempMonday.getTime() + (1000 * 60 * 60 * 24)) < firstOfNextMonthSaved.getTime()) {
                secondMonday = firstMondayNextMonth.add('d', 14);
            } else {
                secondMonday = firstMondayNextMonth.add('d', 7);
            }
            return secondMonday;
        }
    }

	comboFromArray1 = new Ext.ux.form.CheckboxCombo({
		id: 'comboFromArray1',
		applyTo: 'baseline',
		width: 400,
		mode: 'local',
		store: storeContent,
		valueField: 'full',
		displayField: 'display',
        emptyText: 'Select content...',
		allowBlank: false
	});
	
    // Computer Group DropList (ComboBox) ---------------------------------------------------------------------------------------------------------------------------------
    // Session Relevance
    var rel2 = '("All Computers (" & it as string & ")") of number of bes computers; ("All Windows Computers (" & it as string & ")") of number of bes computers whose (operating system of it as lowercase contains "win"); unique values of (name of it & " (" & size of member sets of it as string & ")") of bes computer groups ; "Custom Relevance Expression (0)"';
    var res2 = EvaluateRelevance(rel2);

	comboFromArray2 = new Ext.ux.form.CheckboxCombo({
		id: 'comboFromArray2',
		applyTo: 'computerGroup',
		width: 400,
		mode: 'local',
		store: res2,
        emptyText: 'Select computer groups...',
		allowBlank: false
	});

    // Populate comboboxes and textareas with info saved in cookies
    var savedFixletComboBox = cp.get('lw-cb-fixlet', 'None');
    var savedComputerComboBox = cp.get('lw-cb-computer', 'None');
    var savedFixletCustom = cp.get('lw-custom-fixlet', 'None');
    var savedComputerCustom = cp.get('lw-custom-computer', 'None');
    var savedMSGroupCheckbox = cp.get('lw-msgroup-checkbox', 'None');
	var savedChartPref = cp.get('lw-chartpref', chartPrefDefault);

    if (savedFixletComboBox != 'None') {
        comboFromArray1.setValue(savedFixletComboBox);
    }
    if (savedComputerComboBox != 'None') {
        comboFromArray2.setValue(savedComputerComboBox);
    }
    if (savedFixletCustom != 'None') {
        textAreaFixlet.setValue(savedFixletCustom);
        customFixletText = savedFixletCustom;
    }
    if (savedComputerCustom != 'None') {
        textAreaComputer.setValue(savedComputerCustom);
        customComputerText = savedComputerCustom;
    }
    if (savedMSGroupCheckbox != 'None') {
        // GroupMSPatches.setValue(savedMSGroupCheckbox);
		Ext.getCmp('GroupMSPatches').setValue(savedMSGroupCheckbox);
    }

	Ext.getCmp('ChartByOutstandingOrPatched').setValue(savedChartPref);

	// This code is intended to show the Custom Relevance textbox if selected by checkbox
	// Decided to always hide until and unless the user click on the toolbar button to show
	/*
    if (savedFixletComboBox == 'R||Custom Relevance Expression||0') {
        document.getElementById('customFixletDiv').style.display = 'block';
    }

    if (savedComputerComboBox == 'Custom Relevance Expression (0)') {
        document.getElementById('customComputerDiv').style.display = 'block';
    } */

    // This function buildGrid is being called by the generateButton -------------------------------------------------------------------------------------------------------

    function buildGrid() {

        document.getElementById('content').innerHTML = '';
		document.getElementById('compliance').innerHTML = '';
		document.getElementById('chart1').innerHTML = '';
		document.getElementById('chart2').innerHTML = '';
		document.getElementById('TimeStampDiv').innerHTML = '';

		var computerFilter = 'unions of (';

		var computerFilterArray = new Array();
		computerFilterArray = comboFromArray2.value.split(',');
		
        for (var i = 0; i < computerFilterArray.length; i++) {
		
	        var type = computerFilterArray[i].substring(0, 1);

			// Strip the computer count number behind the computer group name
			var computerGroup = computerFilterArray[i].substring(0, computerFilterArray[i].lastIndexOf(' ('));
			
			if (computerGroup == 'All Computers') {
				computerFilter = computerFilter + '(sets of bes computers whose (exists name of it))';
			}
			else if (computerGroup == 'All Windows Computers') {
				computerFilter = computerFilter + '(sets of bes computers whose (exists name of it and operating system of it as lowercase contains "win"))';
			}
			else if (computerGroup == 'Custom Relevance Expression') {
				computerFilter = computerFilter + '(sets of ' + textAreaComputer.getValue() + ')';
			}
			else {
				computerFilter = computerFilter + '(sets of members whose (exists name of it) of bes computer groups whose (name of it = "' + computerGroup + '"))';
			}
			
			if (i == computerFilterArray.length -1)
			{
				// This is the last and closing construct for the relevance statement
				computerFilter = computerFilter + ')';
			}
			else
			{
				// This adds the semicolon to separate the computer sets
				computerFilter = computerFilter + '; ';
			}
		}
		
        var fixletFilter = 'elements of unions of (';

		var fixletFilterArray = new Array();
		fixletFilterArray = comboFromArray1.value.split(',');
		
        for (var i = 0; i < fixletFilterArray.length; i++) {
	        var type = fixletFilterArray[i].substring(0, 1);
    	    var contentName = fixletFilterArray[i].substring(3, fixletFilterArray[i].lastIndexOf('||'));
			
	        if (type == 'B') {
	            fixletFilter = fixletFilter + '(sets of source fixlets of components of component groups of bes fixlets whose (baseline flag of it = true and name of it = "' + contentName + '"))';
	        } else if (type == 'S') {
	            fixletFilter = fixletFilter + '(sets of bes fixlets whose (fixlet flag of it = true and display name of site of it = "' + contentName + '"))';
			} else if (type == 'C') {
				fixletFilter = fixletFilter + '(sets of bes fixlets whose (display name of site of it starts with "Patches for Windows" and source severity of it as lowercase = "critical" and name of it as lowercase does not contain "corrupt patch" and name of it as lowercase does not contain "superseded"))';
			// Following options added by Mark Marcherey http://forum.bigfix.com/viewtopic.php?id=5393
			} else if (type == 'I') {
				fixletFilter = fixletFilter + '(sets of bes fixlets whose (display name of site of it starts with "Patches for Windows" and source severity of it as lowercase = "important" and name of it as lowercase does not contain "corrupt patch" and name of it as lowercase does not contain "superseded"))';
			} else if (type == 'M') {
				fixletFilter = fixletFilter + '(sets of bes fixlets whose (display name of site of it starts with "Patches for Windows" and source severity of it as lowercase = "moderate" and name of it as lowercase does not contain "corrupt patch" and name of it as lowercase does not contain "superseded"))';
			} else if (type == 'L') {
				fixletFilter = fixletFilter + '(sets of bes fixlets whose (display name of site of it starts with "Patches for Windows" and source severity of it as lowercase = "low" and name of it as lowercase does not contain "corrupt patch" and name of it as lowercase does not contain "superseded"))';
			} else if (type == 'N') {
				fixletFilter = fixletFilter + '(sets of bes fixlets whose (display name of site of it starts with "Patches for Windows" and source severity of it as lowercase = "none" and name of it as lowercase does not contain "corrupt patch" and name of it as lowercase does not contain "superseded"))';
			} else if (type == 'U') {
				fixletFilter = fixletFilter + '(sets of bes fixlets whose (display name of site of it starts with "Patches for Windows" and source severity of it as lowercase = "<unspecified>" and name of it as lowercase does not contain "corrupt patch" and name of it as lowercase does not contain "superseded"))';	        
	        } else if (type == 'R') {
	            fixletFilter = fixletFilter + '(sets of ' + textAreaFixlet.getValue() + ')';
	        } else if (type == 'A') {
	            fixletFilter = fixletFilter + '(sets of bes fixlets whose (fixlet flag of it = true and display name of site of it starts with "Patches for Windows" and name of it as lowercase does not contain "corrupt patch" and name of it as lowercase does not contain "superseded" and source release date of it >= date "' + patchTuesdayCurrent + '" and source release date of it <= date "' + patchTuesdayCurrentEnd + '"))';
	        } else if (type == 'D') {
	            fixletFilter = fixletFilter + '(sets of bes fixlets whose (fixlet flag of it = true and display name of site of it starts with "Patches for Windows" and name of it as lowercase does not contain "corrupt patch" and name of it as lowercase does not contain "superseded" and source release date of it >= date "' + patchTuesdayPrevious + '" and source release date of it <= date "' + patchTuesdayPreviousEnd + '"))';
	        } else if (type == 'E') {
	            fixletFilter = fixletFilter + '(sets of bes fixlets whose (fixlet flag of it = true and display name of site of it starts with "Patches for Windows" and name of it as lowercase does not contain "corrupt patch" and name of it as lowercase does not contain "superseded" and source release date of it >= date "' + patchTuesdayPrevious2 + '" and source release date of it <= date "' + patchTuesdayPrevious2End + '"))';
	        }
			
			if (i == fixletFilterArray.length -1)
			{
				// This is the last and closing construct for the relevance statement
				fixletFilter = fixletFilter + ')';
			}
			else if (type != 'X')
			{
				// This adds the semicolon to separate the Fixlet sets
				fixletFilter = fixletFilter + '; ';
			}
		}
		
        // Session Relevance - retrieve Fixlets

		if (computerGroup == 'All Computers')
		{
			var FixletRelevance = 'unique values of (("<A name=%22" & name of it & "%22 href=%22" & link href of it & "%22 target=%22_blank%22>" & name of it & "</A>") & "||" & id of it as string & "||" & (if (exists category of it) then (if (category of it as lowercase contains "<unspecified>") then (category of it as string) else ("Unspecified") ) else ("Unknown")) & "||" & (if (exists source severity of it) then  (if (source severity of it as lowercase contains "<unspecified>" or source severity of it as lowercase contains "<n/a>") then ("Unspecified") else (source severity of it) ) else ("Unspecified")) & "||" & (if (exists source release date of it) then ((year of it as string & "/" & month of it as two digits & "/" & day_of_month of it as two digits & " (" & day_of_week of it as three letters & ")") of source release date of it) else ("--")) & "||" & number of results whose (exists last became relevant of it AND exists last became nonrelevant of it and last became relevant of it < last became nonrelevant of it) of it as string & "||" & number of results whose (relevant flag of it) of it as string & "||0||0||" & name of site of it) of ' + fixletFilter;
		}
		else 
		{
			var FixletRelevance = 'unique values of (("<A name=%22" & name of it & "%22 href=%22" & link href of it & "%22 target=%22_blank%22>" & name of it & "</A>") & "||" & id of it as string & "||" & (if (exists category of it) then (if (category of it as lowercase contains "<unspecified>") then (category of it as string) else ("Unspecified") ) else ("Unknown")) & "||" & (if (exists source severity of it) then  (if (source severity of it as lowercase contains "<unspecified>" or source severity of it as lowercase contains "<n/a>") then ("Unspecified") else (source severity of it) ) else ("Unspecified")) & "||" & (if (exists source release date of it) then ((year of it as string & "/" & month of it as two digits & "/" & day_of_month of it as two digits & " (" & day_of_week of it as three letters & ")") of source release date of it) else ("--")) & "||" & number of elements of intersection of (' + computerFilter + ' ; it) of sets of computers of results whose (exists last became relevant of it AND exists last became nonrelevant of it and last became relevant of it < last became nonrelevant of it) of it as string & "||" & number of elements of intersection of (' + computerFilter + ' ; it) of sets of computers of results whose (relevant flag of it) of it as string & "||0||0||" & name of site of it) of ' + fixletFilter;
		}
		
        try {
			// alert(FixletRelevance);
            var FixletResultsArray = EvaluateRelevance(FixletRelevance);
            totalFixlets = FixletResultsArray.length;
        }
        catch(e) {
	
			if (computerFilter == '' || computerFilter == 'Session Relevance returning Computers') {
                errMsg = '<b>Error:</b> The relevance statement is empty';
            } else {
                errMsg = '<b>Error:</b> ' + e.message + '<br/><br/><b>Statement:</b><br/> ' + FixletRelevance;
            }

            Ext.Msg.show({
                title: 'Error in Session Relevance querying for Computers',
                msg: errMsg,
                buttons: Ext.Msg.OK,
                icon: Ext.MessageBox.ERROR,
                minWidth: 350
            });
            Ext.TaskMgr.stopAll();
        }
		
        var outstandingFixletsArray = [];
        // var outstandingFixletsArrayComplete = [];
        var memoryProxy = new Ext.data.MemoryProxy(outstandingFixletsArray);

        myChartData = [];
        var cnt = -1;
        var chartData = [];
        var currentName = 'XXX';
        var currentCount = -1;
        var uniqueCount = -1;
        var computerID = '';
        var found = false;

        // ========================================================================================================
        var currentComputerIDinRes = 0;
		var FixletComplianceArray = [];
		var FixletComplianceArrayMinus = [];
		var chartItemCount = -1;
		
		
		// Module to calculate total computers and compliance percentage.
		for (var i = 0; i < FixletResultsArray.length; i++)
		{
			var dataArray = FixletResultsArray[i].split('||');
			FixletComplianceArray[i] = dataArray;
			// Index 7 is TotalComputers, 5 is ComputersPatched, 6 is ComputersOutstanding
			FixletComplianceArray[i][7] = (parseInt(FixletComplianceArray[i][5]) + parseInt(FixletComplianceArray[i][6])).toString();
            if (FixletComplianceArray[i][7] != 0) {
                FixletComplianceArray[i][8] = ((parseFloat(FixletComplianceArray[i][5]) / parseFloat(FixletComplianceArray[i][7])) * 100).toFixed(2);
            }
			else {
				FixletComplianceArray[i][8] = valueForZeroApplicable;
			}
			
			if (parseInt(FixletComplianceArray[i][7]) > 0)
			{
				chartItemCount++;
				var chartData = [];

				chartData[0] = parseInt(FixletComplianceArray[i][6]);
				chartData[1] = parseInt(FixletComplianceArray[i][5]);			
				chartData[2] = FixletComplianceArray[i][0];

				myChartData[chartItemCount] = chartData;
			} 
		}

		// Example output		
		// Administrative Login Needed,240,Computer Support,Important,None,25,1,26,96.15
		var FixletComplianceArrayWithMSGrouped = new Array();
		var currentMSPatchCount = -1; 
		var foundMatch = false;
		var previousFixletName = 'Dummy1234567890';
		var previousFixlet = ['target="_blank">Dummy1234567890</A>', 123, 'Category', 'Severity', 'ReleaseDate', 0, 0, 0, 1.0];
		var HighestSeverity = '';
		var EarliestSourceReleaseDate = 'xxx';
		var EvansMultiFixletLink = '';
		var WebReportsVersion = '';
		
		// Module to combine the MS patches into one. So we get only one MS10-021 for example
		if (Ext.getCmp('GroupMSPatches').checked)
		{			
			chartItemCount = -1;
			myChartData = [];

			// Check for Web Reports version...
			if (document.getElementById('wr_version') != null)
			{
				// Found version 7.x
				WebReportsVersion = '7';
			}
			else
			{	
				// Else assume 8.x			
				WebReportsVersion = '8'; 
			}
			
			for (var j = 0; j < FixletComplianceArray.length; j++)
			{				
				var currentFixlet = FixletComplianceArray[j].slice();
				var currentFixletName = currentFixlet[0].substr(currentFixlet[0].indexOf('"_blank">') + 9, currentFixlet[0].indexOf('</A>') - currentFixlet[0].indexOf('"_blank">') - 9 );
				var previousFixletName = previousFixlet[0].substr(previousFixlet[0].indexOf('"_blank">') + 9, previousFixlet[0].indexOf('</A>') - previousFixlet[0].indexOf('"_blank">') - 9 );;
				
				if (currentFixletName.substr(0,2) != 'MS' || (currentFixletName.substr(0,8) != previousFixletName.substr(0,8)) )
				{
					// Singleton Fixlet
					currentMSPatchCount++;
					FixletComplianceArrayWithMSGrouped[currentMSPatchCount] = currentFixlet.slice();	
					HighestSeverity = currentFixlet[3];
					EarliestSourceReleaseDate = currentFixlet[4];
					
					previousFixlet = currentFixlet.slice();

					EvansMultiFixletLink = ''; // Clear the multi MS Fixlet link
					EvansMultiFixletLink += '&FixletParam=' + currentFixlet[9] + '/' + currentFixlet[1]; 
					
					{
						if (chartItemCount == -1 || parseInt(myChartData[chartItemCount][0]) != 0 || parseInt(myChartData[chartItemCount][1]) != 0 )
							chartItemCount++;						

						var chartData = [];
						chartData[0] = parseInt(currentFixlet[6]);
						chartData[1] = parseInt(currentFixlet[5]);
						chartData[2] = currentFixlet[0];
						myChartData[chartItemCount] = chartData;
					}

				}
				else 
				{
					// Index 7 is TotalComputers, 5 is ComputersPatched, 6 is ComputersOutstanding
					previousFixlet[5] = (parseInt(previousFixlet[5]) + parseInt(currentFixlet[5])).toString();
					previousFixlet[6] = (parseInt(previousFixlet[6]) + parseInt(currentFixlet[6])).toString();
					previousFixlet[7] = (parseInt(previousFixlet[7]) + parseInt(currentFixlet[7])).toString();

		            if (previousFixlet[7] != 0) {
		                previousFixlet[8] = ((parseFloat(previousFixlet[5]) / parseFloat(previousFixlet[7])) * 100).toFixed(2);
		            }
					else {previousFixlet[8] = valueForZeroApplicable;}
										
					FixletComplianceArrayWithMSGrouped[currentMSPatchCount] = previousFixlet.slice();

					if (currentFixletName.substr(0,previousFixletName.indexOf(' - ', 9)).length > 2)
					{
						FixletComplianceArrayWithMSGrouped[currentMSPatchCount][0] = previousFixletName.substr(0,previousFixletName.indexOf(' - ', 9));
					}
					else
					{
						FixletComplianceArrayWithMSGrouped[currentMSPatchCount][0] = previousFixletName;
					}
					
					EvansMultiFixletLink += '&FixletParam=' + currentFixlet[9] + '/' + currentFixlet[1]; 

					// <A name="MS10-016: Vulnerability in Windows Movie Maker Could Allow Remote Code Execution - Producer 2003" 
					// href="/webreports?page=SingleFixletReport&FixletID=Enterprise%2520Security%2f1001623" 
					// target="_blank">
					// MS10-016: Vulnerability in Windows Movie Maker Could Allow Remote Code Execution - Producer 2003
					// </A>
		
					// http://corona:52312/webreports?FixletNameBegins=ms09&ReportName=Open%20Vulnerabilities%20List&ReportType=rf&page=CreateNewReport2
					
					var FixletNameWithLink = '';
					
					if (WebReportsVersion == '7')
					{
						FixletNameWithLink = '<A name="' + previousFixletName + '" href="/webreports?FixletNameBegins=' +
							previousFixletName.substr(0,8) + '&ReportName=Open%20Vulnerabilities%20List&ReportType=tf&page=CreateNewReport2' + '" target="_blank">**' +
							previousFixletName.substr(0, previousFixletName.substr(9).indexOf(' - ') + 9 ) + '</A>';			
					}
					else if (WebReportsVersion == '8')
					{
						FixletNameWithLink = '<A name="' + previousFixletName + '" href="/webreports?' +
							EvansMultiFixletLink + 
							'&ReportName=Progress+of+Top+10+Critical+%2f+Important+Issues&page=FixletProgressReport" target="_blank">'			+
							'**' + previousFixletName.substr(0, previousFixletName.substr(9).indexOf(' - ') + 9 ) + '</A>';
					}
					
					FixletComplianceArrayWithMSGrouped[currentMSPatchCount][0] = FixletNameWithLink;  // Index 0 is Fixlet Name
					FixletComplianceArrayWithMSGrouped[currentMSPatchCount][1] = 0;  // Index 1 is Fixlet ID

					// This section ensures that for an MS bulletin that is grouped, we display the highest severity rating					
					if      (currentFixlet[3] == 'Critical' )
						HighestSeverity = 'Critical'; 
						
					else if (currentFixlet[3] == 'Important' && 
							 (HighestSeverity != 'Critical' )
							 )
						HighestSeverity = 	'Important';			
						
					else if (currentFixlet[3] == 'Moderate' && 
							 (HighestSeverity != 'Critical' &&
							  HighestSeverity != 'Important' )
							)
						HighestSeverity = 	'Moderate';			
						
					else if (currentFixlet[3] == 'Low' && 
							 (HighestSeverity != 'Critical'  && 
 							  HighestSeverity != 'Important' && 
							  HighestSeverity != 'Moderate' )
							)
						HighestSeverity = 	'Low';			
						
					else if (currentFixlet[3] == 'None' && 
							 (HighestSeverity != 'Critical'  && 
 							  HighestSeverity != 'Important' && 
							  HighestSeverity != 'Moderate'  &&
 							  HighestSeverity != 'Low' ) 
							)
						HighestSeverity = 	'None';			
						
					// This section determines the earliest Source Release date for a patch bulletin group
					if (currentFixlet[4] < EarliestSourceReleaseDate)
						EarliestSourceReleaseDate = currentFixlet[4];
						
					// Populate the array used for charting							
					{
						var chartData = [];
						chartData[0] = parseInt(previousFixlet[6]);
						chartData[1] = parseInt(previousFixlet[5]);
						chartData[2] = previousFixlet[0];
						myChartData[chartItemCount] = chartData;	
					}
				}
			}
			
			
			// Sets the severity of the MS Group to the highest severity found
			// and the Source Release date to the earlist
			FixletComplianceArrayWithMSGrouped[currentMSPatchCount][3] = HighestSeverity;
			FixletComplianceArrayWithMSGrouped[currentMSPatchCount][4] = EarliestSourceReleaseDate;
			
			FixletComplianceArray = FixletComplianceArrayWithMSGrouped;		
			totalFixlets = 	FixletComplianceArray.length;
		}
		
        function severityColor(val) {
            if (val.toLowerCase() == 'critical' || val.toLowerCase() == 'high' || val.toLowerCase() == 'critical fixes' || val.toLowerCase() == 'high impact/highly pervasive') {
                return '<span style="color:red;">' + val + '</span>';
            } else if (val.toLowerCase() == 'important' || val.toLowerCase() == 'medium') {
                return '<span style="color:darkorange;">' + val + '</span>';
            } else if (val.toLowerCase() == 'moderate' || val.toLowerCase() == 'security advisory') {
                return '<span style="color:#15428b;">' + val + '</span>';
            } else if (val.toLowerCase() == 'low') {
                return '<span style="color:green;">' + val + '</span>';
            }

            return val;
        }

        function complianceColor(val) {
            if (val >= 90) {
                return '<span style="color:green;">' + val.toFixed(2) + '%</span>';
            } else if (val >= 70 && val < 90) {
                return '<span style="color:#15428b;">' + val.toFixed(2) + '%</span>';
            } else if (val <= 20 && val >= 0) {
                return '<span style="color:red;">' + val.toFixed(2) + '%</span>';
            } else if (val == -99) {
                return '<span style="color:#15428b;">--</span>';
            } else {
                return '<span style="color:darkorange;">' + val.toFixed(2) + '%</span>';
            }
        }

        function complianceColorForExport(val) {
            if (val == -99) {
                return '-';
            } else {
                return val.toFixed(2);
            }
        }

        function sourceReleaseDateFormat(val) {
            var tempDate = new Date(1000, 0, 1);
            if (val.getTime() == tempDate.getTime()) {
                return '<span>--</span>';
            } else {
                return '<span>' + Ext.util.Format.date(val, 'Y/m/d (D)') + '</span>';
            }
        }

        var pStore2 = new Ext.data.ArrayStore({
            fields: [{
                name: 'FixletName'
            },
            {
                name: 'FixletID'
            },
            {
                name: 'Category'
            },
            {
                name: 'SourceSeverity'
            },
            {
                name: 'SourceReleaseDate'
            },
            {
                name: 'ComputersPatched',
                type: 'int'
            },
            {
                name: 'ComputersOutstanding',
                type: 'int'
            },
            {
                name: 'TotalComputers',
                type: 'int'
            },
            {
                name: 'Compliance',
                type: 'float'
            },
			{
                name: 'SiteName'		
			}]
        });

        var pStore = new Ext.ux.data.PagingArrayStore({
            fields: [{
                name: 'FixletName'
            },
            {
                name: 'FixletID'
            },
            {
                name: 'Category'
            },
            {
                name: 'SourceSeverity'
            },
            {
                name: 'SourceReleaseDate'
            },
            {
                name: 'ComputersPatched',
                type: 'int'
            },
            {
                name: 'ComputersOutstanding',
                type: 'int'
            },
            {
                name: 'TotalComputers',
                type: 'int'
            },
            {
                name: 'Compliance',
                type: 'float'
            },			
			{
                name: 'SiteName'		
			}],
            lastOptions: {
                params: {
                    start: 0,
                    limit: 20
                }
            }
        });

        // manually load local data
		pStore.loadData(FixletComplianceArray);

        totalComputersPatched = sumIndex(FixletComplianceArray, 5);
        totalComputersOutstanding = sumIndex(FixletComplianceArray, 6);
        totalComputers = sumIndex(FixletComplianceArray, 7);

        if (totalComputersPatched == 0) {
            compliancePercentage = 100;
        } else {
            compliancePercentage = (parseFloat(totalComputersPatched) / parseFloat(totalComputers) * 100).toFixed(2);
        }

        if (compliancePercentage >= 90) {
            complianceHTML = '<h1 style="margin-bottom: 5px"><font size="4" color="#008800"><center>' + compliancePercentage + '% Compliant</center></font></h1>';
        } else if (compliancePercentage >= 70 && compliancePercentage < 90) {
            complianceHTML = '<h1 style="margin-bottom: 5px"><font size="4" color="orange"><center>' + compliancePercentage + '% Compliant</center></font></h1>';
        } else if (compliancePercentage <= 20) {
            complianceHTML = '<h1 style="margin-bottom: 5px"><font size="4" color="#cd3636"><center>' + compliancePercentage + '% Compliant</center></font></h1>';
        } else {
            complianceHTML = '<h1 style="margin-bottom: 5px"><font size="4" color="#15428b"><center>' + compliancePercentage + '% Compliant</center></font></h1>';
        }

        complianceLegendHTML = '';
        complianceLegendHTML += '<center><table style="margin-top: 6px;" border="0"><tr><td><img src="/ext-3.2.0/resources/images/default/lw/green.png" alt="Installed" /></td><td style="font:bold 10px tahoma,arial,verdana,sans-serif; color:#15428b;">&nbsp;&nbsp;Installed:</td><td style="font:bold 10px tahoma,arial,verdana,sans-serif; color:#15428b;" align="right">';
        complianceLegendHTML += addCommas(totalComputersPatched);
        complianceLegendHTML += '</td></tr><tr><td><img src="/ext-3.2.0/resources/images/default/lw/red.png" alt="Outstanding" /></td><td style="font:bold 10px tahoma,arial,verdana,sans-serif; color:#15428b;">&nbsp;&nbsp;Outstanding:&nbsp;&nbsp;</td><td style="font:bold 10px tahoma,arial,verdana,sans-serif; color:#15428b;" align="right">';
        complianceLegendHTML += addCommas(totalComputersOutstanding);
        complianceLegendHTML += '</td></tr></table></center>';

        function sumIndex(arr, index) {
            var sum = 0;

            for (var i = 0; i < arr.length; i++) {
                if (!isNaN(arr[i][index])) sum += parseInt(arr[i][index]);
            }
            return sum;
        }

        // create the Grid
        var gridCompliance = new Ext.grid.GridPanel({
            iconCls: 'icon-compliance',
            store: pStore,
            columns: [			
            {
				id: 'Fixlet',
                header: 'Fixlet',
                sortable: true,
                width: 140,
                dataIndex: 'FixletName'
            },
			{
                id: 'FixletID',
                header: 'Fixlet ID',
                sortable: true,
                width: 100,
                dataIndex: 'FixletID',
                hidden: true
            },
            {
                header: 'Category',
                sortable: true,
                width: 140,
                dataIndex: 'Category',
                align: 'center',
				hidden: true
            },
            {
                header: 'Severity',
                sortable: true,
                width: 90,
                align: 'center',
                dataIndex: 'SourceSeverity',
                tooltip: '<b>Source Severity</b><br/>For an MS bulletin that is grouped,<br/>this is the highest severity found',
                renderer: severityColor
            },
            {
                header: 'Release Date',
                sortable: true,
                width: 105,
                tooltip: '<b>Source Release Date</b><br/>For an MS bulletin that is grouped,<br/>this is the earlist release date',
                dataIndex: 'SourceReleaseDate'
            },
            {
                header: 'Applicable',
                sortable: true,
                width: 85,
                align: 'right',
                tooltip: '<b>Total Computers</b><br/>Computers that are relevant at some point<br/>Installed plus Outstanding always add up to Applicable',
                dataIndex: 'TotalComputers'
            },
            {
                header: 'Installed',
                sortable: true,
                width: 75,
                align: 'right',
                tooltip: '<b>Computers with Patched Installed</b><br/>Remediated and no longer relevant',
                dataIndex: 'ComputersPatched'
            },
            {
                header: 'Outstanding',
                sortable: true,
                width: 90,
                align: 'right',
                tooltip: '<b>Computers Outstanding</b><br/>Computers that are still relevant',
                dataIndex: 'ComputersOutstanding'
            },
            {
                header: 'Compliance',
                sortable: true,
                width: 90,
                align: 'right',
                tooltip: '<b>Compliance Percentage</b><br/>Compliance is calculated by:<br/>Installed / Applicable',
                dataIndex: 'Compliance',
                renderer: complianceColor
            }],
            stripeRows: true,
			autoExpandColumn: 'Fixlet',
            // height: 580,
			height: 550,
            width: 1000,
            // columnLines: true,
            title: 'Compliance by Computers',
            collapsible: true,
            animCollapse: false,
            renderTo: 'compliance',
            // config options for stateful behavior
            stateful: true,
            stateId: 'gridComplianceByFixlet',

            // paging bar on the bottom
            bbar: new Ext.PagingToolbar({
                pageSize: 20,
                store: pStore,
                displayInfo: true,
                displayMsg: 'Displaying items {0} - {1} of {2}',
                emptyMsg: 'No items to display'
            }),
            tbar: new Ext.Toolbar({
                items: [{
                    xtype: 'tbfill'
                },
                {
                    xtype: 'tbseparator'
                },
                {
                    xtype: 'checkbox',
                    id: 'checkBoxShowAll',
                    name: 'checkBoxShowAll',
				    fieldLabel: 'Label',
					boxLabel: 'Hide Fixlets with 0 Applicable Computers ',
                    handler: function () {
                        var hideComputers;
                        hideComputers = Ext.getCmp('checkBoxShowAll').getValue();

                        if (hideComputers) {
                            if (FixletComplianceArrayMinus.length == 0) {
                                for (var i = 0; i < FixletComplianceArray.length; i++) {
                                    // Index 5 is applicable fixlet count
                                    if (FixletComplianceArray[i][7] > 0) {
                                        FixletComplianceArrayMinus.push(FixletComplianceArray[i]);
                                    }
                                }
                            }
                            pStore.loadData(FixletComplianceArrayMinus);
							gridCompliance.setTitle('Compliance for ' + contentName + ' - by ' + computerGroup + ': (' + FixletComplianceArrayMinus.length + ' total items)');

                        } else {
                            pStore.loadData(FixletComplianceArray);
							gridCompliance.setTitle('Compliance for ' + contentName + ' - by ' + computerGroup + ': (' + FixletComplianceArray.length + ' total items)');
                        } 
                    }
                },
                {
                    xtype: 'tbseparator'
                },
                {
                    xtype: 'tbbutton',
                    iconCls: 'icon-print',
                    text: 'Print',
                    scale: 'small',
                    handler: function () {
                        var hideComputers;
                        hideComputers = Ext.getCmp('checkBoxShowAll').getValue();

                        if (hideComputers) {
                            pStore2.loadData(FixletComplianceArrayMinus);
                        } else {
                            pStore2.loadData(FixletComplianceArray);
                        }

                        // If the data has been sorted via clicking the column headings, do the same for the data to be printed
                        if (pStore.sortInfo != null) {
                            pStore2.sort(pStore.sortInfo.field, pStore.sortInfo.direction);
                        }
                        var newColumnModel = gridCompliance.getColumnModel();
                        gridCompliance.reconfigure(pStore2, newColumnModel);
                        Ext.ux.Printer.print(gridCompliance);
                        gridCompliance.reconfigure(pStore, newColumnModel);
                    }
                },
                {
                    xtype: 'tbseparator'
                },
                {
                    xtype: 'tbbutton',
                    iconCls: 'icon-excel',
                    text: 'Excel',
                    scale: 'small',
                    handler: function () {

						if (Ext.isGecko == false && Ext.isSafari == false)
						{
			                Ext.Msg.show({
			                    title: 'Sorry!',
			                    msg: 'The export to Excel function is only available in FireFox or Safari',
			                    buttons: Ext.Msg.OK,
			                    icon: Ext.MessageBox.INFO,
			                    minWidth: 300
			                });
							return;
						}

                        info('Generating data for Excel...', 2000, 'compliance', -400);

                        document.getElementById('footer').innerHTML = '';

                        var hideComputers;
                        hideComputers = Ext.getCmp('checkBoxShowAll').getValue();

                        if (hideComputers) {
                            pStore2.loadData(FixletComplianceArrayMinus);
                        } else {
                            pStore2.loadData(FixletComplianceArray);
                        }

                        // If the data has been sorted via clicking the column headings, do the same for the data to be printed
                        if (pStore.sortInfo != null) {
                            pStore2.sort(pStore.sortInfo.field, pStore.sortInfo.direction);
                        }

                        var newColumnModel = gridCompliance.getColumnModel();
                        // For the purpose of exporting, we have expanded the grid with full data
                        gridCompliance.reconfigure(pStore2, newColumnModel);
						// Column index 8 is the compliance percentage column, the following gets rid of the '%' sign before export
						newColumnModel.setRenderer(8, complianceColorForExport);

                        var exportButton = new Ext.ux.Exporter.Button({
                            name: 'excelLinkButton',
                            id: 'excelLinkButton',
                            text: '.',
                            component: gridCompliance,
                            renderTo: 'footer',
                            store: pStore2
                        });
                        // This is a very convoluted way of doing Excel export
                        // The library that I use puts the functionality in a button.
                        // However, the buttons needs to be dynamically generated to associate 
                        // the latest set of data.				        
                        // window.open(exportButton.getEl().child('a', true).href, "name");
                        window.location.href = exportButton.getEl().child('a', true).href;

                        // Put the grid back to its original state with paging
						newColumnModel.setRenderer(8, complianceColor);
                        gridCompliance.reconfigure(pStore, newColumnModel);
                    }
                },
                {
                    xtype: 'tbseparator'
                }]
            })
        });

		gridCompliance.setTitle('Compliance for ' + contentName + ' - by ' + computerGroup + ': (' + totalFixlets + ' total items)');

		if (Ext.getCmp('GroupMSPatches').checked)
		{
			var newColumnModel = gridCompliance.getColumnModel();
			newColumnModel.setColumnHeader(0, 'Fixlets (**Multiple items grouped)');			
		}
		else
		{
			var newColumnModel = gridCompliance.getColumnModel();
			newColumnModel.setColumnHeader(0, 'Fixlets');						
		}

        // Disable the superflous Refresh button for the PagingToolbar
        gridCompliance.getBottomToolbar().refresh.hideParent = true;
        gridCompliance.getBottomToolbar().refresh.hide();
		
		gridCompliance.getEl().mask('Loading...', 'x-mask-loading');
        // pStore.loadData(dataComplianceArray);

		gridCompliance.getEl().unmask();

    } // End buildGrid function

    // Charting ------------------------------------------------------------------------------------------------------------------------------------------------------------

    function buildChart() {

        var divChart1 = document.getElementById('chart1');
        divChart1.innerHTML = '';

        var divChart2 = document.getElementById('chart2');
        divChart2.innerHTML = '';

        var storeChart = new Ext.data.ArrayStore({
            fields: [{
                name: 'Outstanding',
                type: 'float'
            },
			{
                name: 'Installed',
                type: 'float'
            },
            {
                name: 'name'
            }]
        });

        var storeChartMinus = new Ext.data.ArrayStore({
            fields: [{
                name: 'Outstanding',
                type: 'float'
            },
			{
                name: 'Installed',
                type: 'float'
            },
            {
                name: 'name'
            }]
        });

		var chartTitle = '';
		
		storeChart.loadData(myChartData);
		
		if (Ext.getCmp('ChartByOutstandingOrPatched').getValue() == chartPrefDefault)
		{			
			chartTitle = ' Most Outstanding/Vulnerable Fixlets';
			storeChart.sort([
					{
						field: 'Outstanding',
						direction: 'DESC'
					},
					{
						field: 'Installed',
						direction: 'DESC'
					}
			]);
		}	
		else 
		{
			chartTitle = ' Most Installed/Patched Fixlets';
			storeChart.sort([
					{
						field: 'Installed',
						direction: 'DESC'
					},
					{
						field: 'Outstanding',
						direction: 'DESC'
					}
			]);
		}
				
        var maximumItemsForChart = 15;
			
        if (storeChart.getCount() > maximumItemsForChart) {
			storeChartMinus.add(storeChart.getRange(0,maximumItemsForChart-1));
			chartTitle = maximumItemsForChart + chartTitle;
        } else {
			storeChartMinus.add(storeChart.getRange(0,storeChart.getCount()));
			chartTitle = storeChart.getCount() + chartTitle;
        } 
		
		
		function FixletNameFormat(val){
			var labelToDisplay =  val.substr(val.indexOf('"_blank">') + 9, val.indexOf('</A>') - val.indexOf('"_blank">') - 9 );
			return labelToDisplay.substr(0, 15) + '..';	
		}
		
        new Ext.Panel({
            iconCls: 'chart-bar',
            title: chartTitle,
            frame: true,
            renderTo: 'chart2',
            collapsible: true,
            animCollapse: false,
            width: 788,
            height: 300,
            layout: 'anchor',

            items: [{
                region: 'west',
                xtype: 'stackedcolumnchart',
                store: storeChartMinus,
                url: '/ext-3.2.0/resources/charts.swf',
                xField: 'name',
				
				xAxis: new Ext.chart.CategoryAxis({
					labelRenderer: FixletNameFormat
				}),
                yAxis: new Ext.chart.NumericAxis({
                    title: 'Number of Computers',
                    displayName: 'Patches',
                    alwaysShowZero: true,
                    labelRenderer: Ext.util.Format.numberRenderer('0,0')
                    // majorUnit: 5,
                    // minorUnit: 1
                }),
                tipRenderer: function (chart, record, index, series) {
					var labelToDisplay =  record.data.name.substr(
							record.data.name.indexOf('"_blank">') + 9, 
							record.data.name.indexOf('</A>') - record.data.name.indexOf('"_blank">') - 9 );
					
					var maximumLabelWidth = 100;
					
					if (labelToDisplay.length > maximumLabelWidth)
					{
						labelToDisplay = labelToDisplay.substr(0, maximumLabelWidth/2) + '...' + labelToDisplay.substr(labelToDisplay.length - maximumLabelWidth/2 , labelToDisplay.length)	
					}
					
                    if (series.yField == 'Outstanding') {
                            return Ext.util.Format.number(record.data.Outstanding, '0,0') + ' outstanding: ' + labelToDisplay;
                    }
                    if (series.yField == 'Installed') {
                            return Ext.util.Format.number(record.data.Installed, '0,0') + ' installed: ' + labelToDisplay;
                    }
                },
				extraStyle:{
					legend:{
						display: 'right'
					}
				},
                chartStyle: {
                    padding: 10,
                    animationEnabled: true,
                    font: {
                        name: 'Tahoma',
                        color: 0x444444,
                        size: 11
                    },
                    dataTip: {
                        padding: 5,
                        border: {
                            color: 0x99bbe8,
                            size: 1
                        },
                        background: {
                            color: 0xDAE7F6,
                            alpha: .9
                        },
                        font: {
                            name: 'Tahoma',
                            color: 0x15428B,
                            size: 10,
                            bold: true
                        }
                    },
                    xAxis: {
                        color: 0x69aBc8,
                        labelRotation: 75,
                        majorTicks: {
                            color: 0x69aBc8,
                            length: 4
                        },
                        minorTicks: {
                            color: 0x69aBc8,
                            length: 2
                        },
                        majorGridLines: {
                            size: 1,
                            color: 0xeeeeee
                        }
                    },
                    yAxis: {
                        titleRotation: -90,
                        color: 0x69aBc8,
                        majorTicks: {
                            color: 0x69aBc8,
                            length: 4
                        },
                        minorTicks: {
                            color: 0x69aBc8,
                            length: 2
                        },
                        majorGridLines: {
                            size: 1,
                            color: 0xdfe8f6
                        }
                    }
                },
                series: [{
                    type: 'column',
                    yField: 'Outstanding',
					displayName: 'Outstanding',
                    style: {
                        image: '/ext-3.2.0/resources/images/default/lw/red-bar.gif',
                        mode: 'stretch',
                        color: 0xcd3636
                    }
                },{
                    type: 'column',
                    yField: 'Installed',
					displayName: 'Installed',
                    style: {
                        image: '/ext-3.2.0/resources/images/default/lw/green-bar.png',
                        mode: 'stretch',
                        color: 0x008800
                    }
                }]
            }]
        }); // Chart panel 1
		
        if (totalComputers == 0) {
            var storeChart = new Ext.data.JsonStore({
                fields: ['fixletcount', 'total'],
                data: [{
                    fixletcount: 'Installed',
                    total: totalComputersPatched
                }]
            });
        } else {
            var storeChart = new Ext.data.JsonStore({
                fields: ['fixletcount', 'total'],
                data: [{
                    fixletcount: 'Installed',
                    total: totalComputersPatched
                },
                {
                    fixletcount: 'Outstanding',
                    total: totalComputersOutstanding
                }]
            });
        }

        new Ext.Panel({
            iconCls: 'chart-pie',
            frame: true,
            width: 200,
            height: 300,
            title: 'Compliance Summary',
            collapsible: true,
            animCollapse: false,
            renderTo: 'chart1',
            items: [{
                html: complianceHTML
            },
            {
                store: storeChart,
                xtype: 'piechart',
                url: '/ext-3.2.0/resources/charts.swf',
                dataField: 'total',
                height: 200,
                bottom: 50,
                categoryField: 'fixletcount',
                series: [{
                    // Green: 0x008800, 
                    // Red: 0xcc3333
					// New Green: 0x6eb924
					// New Red: 0xd14747
					// New Darker Green: 0x64a821
					// New Darker Red: 0xcd3636
                    style: {
                        colors: [0x008800, 0xcd3636]
                    }
                }]
            },
            {
                html: complianceLegendHTML
            }]
        }); // Chart panel 2
    } // Build grid

    function info(msg, timeout, div, offsetY) {
        new Ext.ux.window.MessageWindow({
            title: 'Message:',
            html: msg || 'No information available',
            origin: {
                el: Ext.get(div),
                //element to align to 
                offX: -0.5 * Ext.get(div).getWidth(),
                //amount to offset horizontally
                offY: offsetY
            },
            autoHeight: true,
            pinOnClick: false,
            iconCls: 'icon-info',
            help: false,
            hideFx: {
                delay: timeout,
                mode: 'standard'
            }
        }).show(Ext.getDoc());
    } //function info()

    function addCommas(nStr) {
        nStr += '';
        x = nStr.split('.');
        x1 = x[0];
        x2 = x.length > 1 ? '.' + x[1] : '';
        var rgx = /(\d+)(\d{3})/;
        while (rgx.test(x1)) {
            x1 = x1.replace(rgx, '$1' + ',' + '$2');
        }
        return x1 + x2;
    }

    //finally, remove the loading mask
    (function () {
        Ext.get('loading').remove();
        Ext.get('loading-mask').fadeOut({
            remove: true
        });
    }).defer(250);

}); // onReady

