 /* 
 Asset Management Dashboard
 Created by Lee Wei
 Last updated May 21th 2010
 Version 1.2
*/ 

Ext.BLANK_IMAGE_URL = '/ext-3.2.0/resources/images/default/s.gif';

Ext.onReady(function () {

    Ext.QuickTips.init();

    var gridComputer;
	var allComputers = new Array();
	var activeComputerGroup;
    var ConfigWin;
	var storeProp; 

	var PropertyArrayForComboBoxCurrent = new Array();
    var PropertyArrayForComboBoxAnalysis = new Array();
    var PropertyArrayForComboBoxGlobal = new Array();
    var PropertyArrayForComboBoxCustom = new Array();
	var ActionSiteID;
	// This relevance retrieves the default properties (OS, CPU and RAM) and their site specific IDs
	var DefaultPropertiesRelevance = '(name of it & "^" & item 0 of id of it as string & "," & item 1 of id of it as string & "," & item 2 of id of it as string & "|" & name of it & " (Global)") of bes properties whose (name of it = "OS" and reserved flag of it) ; (name of it & "^" & item 0 of id of it as string & "," & item 1 of id of it as string & "," & item 2 of id of it as string & "|" & name of it & " (Global)") of bes properties whose (name of it = "CPU" and reserved flag of it) ; (name of it & "^" & item 0 of id of it as string & "," & item 1 of id of it as string & "," & item 2 of id of it as string & "|" & name of it & " (Global)") of bes properties whose (name of it = "RAM" and default flag of it)';
	var DefaultProperties;
    var customComputerText = 'Session Relevance returning Computers';
	var computerFilter 
	var gridPanelTitleLength = 47;  // How much space available to display the title
	
	// These are the cookie values saved for the Last Report Time intervals
	var Pie41Saved;
	var Pie42Saved;
	var Pie43Saved;
	var Pie44Saved;

    var cp = new Ext.state.CookieProvider({
        path: "/",
        expires: new Date(new Date().getTime() + (1000 * 60 * 60 * 24 * 180)) //180 days
    });

    Ext.state.Manager.setProvider(cp);

    // Filter Panel ------------------------------------------------------------------------------------------------------------------------------------------------------
    var FiltersPanel = new Ext.Panel({
        id: 'FiltersPanel',
        iconCls: 'icon-filter',
        title: 'Filters (v1.2)',
        renderTo: 'filters',
        width: 1062,
        layout: 'absolute',
        collapsible: true,
        bodyStyle: {
            background: '#cedff5'
        },
        html: '<table><tr>' + '<td><div class="lw-label" style="margin-left: 10px">Computer&nbsp;Group:&nbsp;</div></td>' + 
		'<td><div><input class="lw-combo" type="select" id="computerGroup" size="40"/></div></td>' + 
		'<td><div id="generateButton" style="margin-left: 10px"></div></td>' + 
		'<td><div id="editButton" style="margin-left: 10px"></div></td>' + 
		'<td><div id="configureButton" style="margin-left: 10px"></div></td>' + 
		'<td><div class="lw-label" id="autoRunCheckBoxDiv" style="margin-left: 10px; margin-top: 10px;"></div></td>' + 
		'</tr>' + 
		'<tr>' + 
		'<td></td>' + 
		'<td style="vertical-align:top;"><div id="customComputerDiv" ></div></td>' + 
		'<td></td><td></td><td></td><td></td>' + 
		'</tr>' + 
		'</table>'
    });
	
    var textAreaComputer = new Ext.form.TextArea({
        width: 400,
        height: 100,
        grow: true,
        growMax: 200,
        renderTo: 'customComputerDiv'
    });

    document.getElementById('customComputerDiv').style.display = 'none';


    // Generate Button ------------------------------------------------------------------------------------------------------------------------------------------------------------    
    var generateButton = new Ext.Button({
        iconCls: 'icon-generate',
        text: 'Generate',
        scale: 'small',
        width: '100',
        renderTo: 'generateButton',
        handler: function () {
            GenerateDashboard();
        }
    }); // Button

    // Edit Button ------------------------------------------------------------------------------------------------------------------------------------------------------------    
    var editButton = new Ext.Button({
        iconCls: 'icon-script-edit',
        text: 'Edit Custom Relevance',
        scale: 'small',
		tooltip: '<b>Show or Hide Relevance text box</b><br/>The relevances entered are used by the selection Custom Session Relevance in the filter list',
        width: '150',
        renderTo: 'editButton',
        handler: function () {
            var divCustomComputer = document.getElementById('customComputerDiv');

            if (this.getText() == 'Edit Custom Relevance') {
				this.setText('Hide Custom Relevance');
                divCustomComputer.style.display = 'block';
                textAreaComputer.setValue(customComputerText);
            } else {
				this.setText('Edit Custom Relevance');
                customComputerText = textAreaComputer.getValue();
                divCustomComputer.style.display = 'none';
            }	
        }
    }); // Button

    // Computer Group DropList (ComboBox) ---------------------------------------------------------------------------------------------------------------------------------
    // Session Relevance
    var rel2 = '("All Computers (" & it as string & ")") of number of bes computers; ("All Windows Computers (" & it as string & ")") of number of bes computers whose (operating system of it as lowercase contains "win"); unique values of (name of it & " (" & size of member sets of it as string & ")") of bes computer groups ; "Custom Relevance Expression (0)"';

    try {
	    var res2 = EvaluateRelevance(rel2);
    }
    catch (e) {
        errMsg = '<b>Error:</b> ' + e.message + '<br/><br/><b>Statement:</b><br/> ' + rel2;

        Ext.Msg.show({
            title: 'Error in Session Relevance',
            msg: errMsg,
            buttons: Ext.Msg.OK,
            icon: Ext.MessageBox.ERROR,
            minWidth: 350
        });
    }

	comboFromArray2 = new Ext.ux.form.CheckboxCombo({
		applyTo: 'computerGroup',
		width: 400,
		mode: 'local',
		store: res2,
        emptyText: 'Select computer groups...',
		allowBlank: false
	});

    // Populate comboboxes and textareas with info saved in cookies
    var savedComputerComboBox = cp.get('lw-asset-computer', 'None');
    var savedComputerCustom = cp.get('lw-asset-custom-computer', 'None');
    var savedAutoRunCheckBox = cp.get('lw-asset-autoruncheckbox', 'None');

    if (savedComputerComboBox != 'None') {
        comboFromArray2.setValue(savedComputerComboBox);
    }

    if (savedComputerCustom != 'None') {
        textAreaComputer.setValue(savedComputerCustom);
        customComputerText = savedComputerCustom;
    }

    if (savedComputerComboBox == 'Custom Relevance Expression (0)') {
        document.getElementById('customComputerDiv').style.display = 'block';
		textAreaComputer.setHeight(100);
		editButton.setText('Hide Custom Relevance');
    }
    	
    // Configure Button ------------------------------------------------------------------------------------------------------------------------------------------------------------    
    var configureButton = new Ext.Button({
        iconCls: 'icon-configure',
        text: 'Configure',
        scale: 'small',
		tooltip: '<b>Change the properties being shown</b><br/>Click to change the properties being reported',		
        width: '100',
        renderTo: 'configureButton',
        handler: function () {
            if (!ConfigWin) {

                // Load Properties from Web Reports ------------------------------------------------------------------------------------------------------------------
				var relevancePropertyList = 'unique values of ("A" & name of it & "^" & id of it as string & "|" & (name of it & " (" & name of source analysis of it & ")" )) of bes properties whose (analysis flag of it = true and exists activations of source analysis of it); unique values of ("G" & name of it & "^" & id of it as string & "|" & (name of it & " (Global)")) of bes properties whose (analysis flag of it = false and (default flag of it = true or reserved flag of it = true)); unique values of ("C" & name of it & "^" & id of it as string & "|" & (name of it & " (Custom)")) of bes properties whose (analysis flag of it = false and (custom flag of it = true))';

                try {
                    document.getElementById('loading-indicator').innerHTML = 'Loading Retrieved Property Info...';
                    var relevanceResultsPropertyList = EvaluateRelevance(relevancePropertyList);
                }
                catch (e) {
                    errMsg = '<b>Error:</b> ' + e.message + '<br/><br/><b>Statement:</b><br/> ' + relevancePropertyList;

                    Ext.Msg.show({
                        title: 'Error in Session Relevance',
                        msg: errMsg,
                        buttons: Ext.Msg.OK,
                        icon: Ext.MessageBox.ERROR,
                        minWidth: 350
                    });
                    Ext.TaskMgr.stopAll();
                }

				var propType;
				var analysisCount = 0;
				var globalCount = 0;
				var customCount = 0;
				
                for (var i = 0; i < relevanceResultsPropertyList.length; i++) {
                    var row = new Array();
					propType = 	relevanceResultsPropertyList[i].substring(0,1);
					
                    row[0] = relevanceResultsPropertyList[i].substring(1, relevanceResultsPropertyList[i].indexOf('|'));
                    row[1] = relevanceResultsPropertyList[i].substring(relevanceResultsPropertyList[i].lastIndexOf('|') + 1);
					if (propType == 'G')
					{
						PropertyArrayForComboBoxGlobal[globalCount] = row;
						globalCount++;					
					}
					else if (propType == 'C')
					{
						PropertyArrayForComboBoxCustom[customCount] = row;	
						customCount++;			
					}
					else if (propType == 'A')
					{
						PropertyArrayForComboBoxAnalysis[analysisCount] = row;		
						analysisCount++									
					}
                }
				
                storeProp = new Ext.data.ArrayStore({
                    fields: ['ID', 'DisplayName'],
                    data: PropertyArrayForComboBoxGlobal
                });
				
			    try {
					DefaultProperties = EvaluateRelevance(DefaultPropertiesRelevance);
			    }
			    catch (e) {
			        errMsg = '<b>Error:</b> ' + e.message + '<br/><br/><b>Statement:</b><br/> ' + DefaultPropertiesRelevance;
			
			        Ext.Msg.show({
			            title: 'Error in Session Relevance',
			            msg: errMsg,
			            buttons: Ext.Msg.OK,
			            icon: Ext.MessageBox.ERROR,
			            minWidth: 350
			        });
			    }

                var Pie1Saved = cp.get('lw-asset-pie1', DefaultProperties[0]);
                var Pie2Saved = cp.get('lw-asset-pie2', DefaultProperties[1]);
                var Pie3Saved = cp.get('lw-asset-pie3', DefaultProperties[2]);

				Pie41Saved = cp.get('lw-asset-pie41', '1');
				Pie42Saved = cp.get('lw-asset-pie42', '24');
				Pie43Saved = cp.get('lw-asset-pie43', '7');
				Pie44Saved = cp.get('lw-asset-pie44', '30');
				
                // Create Configure Windows ---------------------------------------------------------------------------------------------------------------------------			
                ConfigWin = new Ext.Window({
                    title: 'Configure Asset Management Dashboard',
                    applyTo: 'config-win',
                    iconCls: 'icon-configure',
                    width: 460,
                    minWidth: 460,
					modal: true,
                    height: 485,
					// autoScroll: true,
                    padding: 10,
                    resizable: false,
                    border: false,
                    layout: 'fit',
                    y: 50,
                    closeAction: 'hide',
                    html: 
						'<table border="0" style="width:100%; margin-right:20px;">						                                               ' + 
						'    <tr>                                                                                                                      ' + 
						'        <td><div class="lw-label" style="width: 60px;">Browse Properties</div></td>                     					   ' + 
						'        <td colspan="2"><input style="width: 340px;" class="lw-combo" type="text" id="PropertyComboBoxDiv"/></td>             ' + 
						'    </tr>                                                                                                                     ' + 
						'    <tr>                                                                                                                      ' + 
						'        <td></td>                                                                                                             ' + 
						'        <td colspan="2">                                                                                                      ' + 
						'			<table border="0" width="100%">                                                                                    ' +
						'				<tr>											                                                        	   ' +
						'					<td><div id="CheckBoxGlobalDiv" class="lw-checkbox"></div></td>									    	   ' +
						'					<td><div id="CheckBoxCustomDiv" class="lw-checkbox"></div></td>											   ' +
						'					<td><div id="CheckBoxAnalysisDiv" class="lw-checkbox"></div></td>										   ' +
						'					<td><div id="CheckBoxAnalysisOptionDiv" class="lw-checkbox"></div></td>									   ' +
						'				</tr>								                                                            			   ' +
						'			</table>                                                                                                           ' +
						'        </td>                                                                                                                 ' + 
						'    </tr>                                                                                                                     ' + 						
						'    <tr>                                                                                                                      ' + 
						'        <td colspan="3" style="height: 5px;"></td>                                                                            ' + 
						'    </tr>                                                                                                                     ' + 
						'    <tr>                                                                                                                      ' + 
						'        <td><div class="lw-label" style="width: 60px;">Pie 1</div></td>                                					   ' + 
						'        <td><div><input style="width: 300px; margin-right:5px;" class="lw-combo" type="text" id="Pie1" READONLY /></div></td> ' + 
						'        <td><div id="Pie1ButtonDiv"></div></td>                                                                               ' + 
						'    </tr>                                                                                                                     ' + 
						'    <tr>                                                                                                                      ' + 
						'        <td colspan="3"><div><input class="lw-combo" type="hidden" id="Pie1ID" /></div></td>                                  ' + 
						'    </tr>                                                                                                                     ' + 
						'    <tr>                                                                                                                      ' + 
						'        <td><div class="lw-label" style="width: 60px;">Pie 2</div></td>                                   					   ' + 
						'        <td><div><input style="width: 300px; margin-right:5px;" class="lw-combo" type="text" id="Pie2"  READONLY /></div></td>' + 
						'        <td><div id="Pie2ButtonDiv"></div></td>                                                                               ' + 
						'    </tr>                                                                                                                     ' + 
						'    <tr>                                                                                                                      ' + 
						'        <td colspan="3"><div><input class="lw-combo" type="hidden" id="Pie2ID" /></div></td>                                  ' + 
						'    </tr>                                                                                                                     ' + 
						'    <tr>                                                                                                                      ' + 
						'        <td><div class="lw-label" style="width: 60px;">Pie 3</div></td>                                    				   ' + 
						'        <td><div><input style="width: 300px; margin-right:5px;" class="lw-combo" type="text" id="Pie3" READONLY  /></div></td>' + 
						'        <td><div id="Pie3ButtonDiv"></div></td>                                                                               ' + 
						'    </tr>                                                                                                                     ' + 
						'    <tr>                                                                                                                      ' + 
						'        <td colspan="3"><div><input class="lw-combo" type="hidden" id="Pie3ID" /></div></td>                                  ' + 
						'    </tr>                                                                                                                     ' +
						'    <tr> 																													   ' +
						'    	<td><div class="lw-label" style="width: 60px;">Pie 4</div></td> 													   ' + 
						'    	<td colspan="2"><div id="Pie4Slider1Div" style="float:left;  margin-right:5px;"></div> 								   ' +
						'			<div style="float:left; margin-top:3px;"> 										 							   	   ' +
						'				<input style="width: 50px; text-align:center;  margin-right:5px;" class="lw-combo" type="text" id="Pie4Value1"  READONLY /></div> ' +
						'			<div style="float:left; margin-top:3px;"> 													   					   ' +
						' 				<input style="width: 50px; text-align:center;" class="lw-combo" type="text" id="Pie4Value2"  READONLY /></div> ' +
						'		</td> 																												   ' + 						 
						'    </tr> 																													   ' + 
						'    <tr> 																													   ' +
						'    	<td><div class="lw-label" style="width: 60px;"></div></td> 										  					   ' + 
						'    	<td colspan="2"><div id="Pie4Slider2Div" style="float:left;  margin-right:5px;"></div> 								   ' +
						'			<div style="float:left; margin-top:3px;"> 										   			   					   ' +
						'				<input style="width: 50px; text-align:center;  margin-right:5px;" class="lw-combo" type="text" id="Pie4Value3"  READONLY /></div> ' +
						'			<div style="float:left; margin-top:3px;"> 										  			   					   ' +
						'				<input style="width: 50px; text-align:center;" class="lw-combo" type="text" id="Pie4Value4"  READONLY /></div> ' +
						'		</td> 																												   ' + 						 
						'    </tr> 																													   ' + 
						'    <tr>                                                                                                                      ' + 
						'        <td><div class="lw-label" style="width: 60px;">Dashboard Layout</div></td>                         				   ' + 
						'        <td colspan="2"><div><img width="350" src="/ext-3.2.0/resources/images/default/lw/configure_dashboard.png"></div></td>      ' + 
						'    </tr>                                                                                                                     ' + 
						'</table>                                                                                                                      ',
                    buttons: [{
                        id: 'ApplyButton',
                        text: 'Apply',
                        scope: this,
                        disabled: true,
                        handler: function () {

                            // Save info as cookies			
                            cp.set('lw-asset-pie1', document.getElementById('Pie1ID').value + '|' + document.getElementById('Pie1').value);
                            cp.set('lw-asset-pie2', document.getElementById('Pie2ID').value + '|' + document.getElementById('Pie2').value);
                            cp.set('lw-asset-pie3', document.getElementById('Pie3ID').value + '|' + document.getElementById('Pie3').value);

							// The text field has format "24 hours", pick the numeric value to be saved
							var pie41 = document.getElementById('Pie4Value1').value;
							var pie42 = document.getElementById('Pie4Value2').value;
							var pie43 = document.getElementById('Pie4Value3').value;
							var pie44 = document.getElementById('Pie4Value4').value;
							pie41 = pie41.substring(0, pie41.indexOf(' '));
							pie42 = pie42.substring(0, pie42.indexOf(' '));
							pie43 = pie43.substring(0, pie43.indexOf(' '));
							pie44 = pie44.substring(0, pie44.indexOf(' '));
							
							cp.set('lw-asset-pie41', pie41);
							cp.set('lw-asset-pie42', pie42);
							cp.set('lw-asset-pie43', pie43);
							cp.set('lw-asset-pie44', pie44);

							document.getElementById('Pie1').style.backgroundColor = "#ffffff";										
							document.getElementById('Pie2').style.backgroundColor = "#ffffff";												
							document.getElementById('Pie3').style.backgroundColor = "#ffffff";												
	
							document.getElementById('Pie4Value1').style.backgroundColor = "#ffffff";												
							document.getElementById('Pie4Value2').style.backgroundColor = "#ffffff";											
							document.getElementById('Pie4Value3').style.backgroundColor = "#ffffff";												
							document.getElementById('Pie4Value4').style.backgroundColor = "#ffffff";											

                            Ext.getCmp('ApplyButton').disable();
                        }
                    },
					{
                        id: 'DefaultButton',
                        text: '&nbsp;&nbsp;Reset to Default&nbsp;&nbsp;',
                        scope: this,
                        handler: function () {
                            // Save info as cookies			
                            cp.set('lw-asset-pie1', DefaultProperties[0]);
                            cp.set('lw-asset-pie2', DefaultProperties[1]);
                            cp.set('lw-asset-pie3', DefaultProperties[2]);
							
							cp.set('lw-asset-pie41', '1');
							cp.set('lw-asset-pie42', '24');
							cp.set('lw-asset-pie43', '7');
							cp.set('lw-asset-pie44', '30');
							
			                document.getElementById('Pie1').value = 'OS (Global)';
							document.getElementById('Pie1ID').value = DefaultProperties[0];
			                document.getElementById('Pie2').value = 'CPU (Global)';
							document.getElementById('Pie2ID').value = DefaultProperties[1];
			                document.getElementById('Pie3').value = 'RAM (Global)';
							document.getElementById('Pie3ID').value = DefaultProperties[2];						

			                document.getElementById('Pie4Value1').value = '1 hour';
			                document.getElementById('Pie4Value2').value = '24 hours';
			                document.getElementById('Pie4Value3').value = '7 days';
			                document.getElementById('Pie4Value4').value = '30 days';
							Pie4Slider1Var.setValue(0, 1, true);
							Pie4Slider1Var.setValue(1, 24, true);
							Pie4Slider2Var.setValue(0, 7, true);
							Pie4Slider2Var.setValue(1, 30, true);
							
							document.getElementById('Pie1').style.backgroundColor = "#ffffff";										
							document.getElementById('Pie2').style.backgroundColor = "#ffffff";												
							document.getElementById('Pie3').style.backgroundColor = "#ffffff";												
	
							document.getElementById('Pie4Value1').style.backgroundColor = "#ffffff";												
							document.getElementById('Pie4Value2').style.backgroundColor = "#ffffff";											
							document.getElementById('Pie4Value3').style.backgroundColor = "#ffffff";												
							document.getElementById('Pie4Value4').style.backgroundColor = "#ffffff";											

                            Ext.getCmp('ApplyButton').disable();
                        }
                    },
                    {
                        text: 'Close',
                        formBind: true,
                        scope: this,
                        handler: function () {
                            ConfigWin.hide();
                        }
                    }]
                });

                var PropertyComboBox = new Ext.form.ComboBox({
                    id: 'PropertyComboBox',
                    cls: 'lw-combo',
                    xtype: 'combo',
                    fieldLabel: 'Select Property',
                    anchor: '-18',
                    allowBlank: true,
                    resizable: true,
                    forceSelection: true,
                    shadow: true,
                    typeAhead: true,
                    triggerAction: 'all',
                    selectOnFocus: true,
                    mode: 'local',
                    store: storeProp,
                    emptyText: 'Browse to a retrieved property...',
                    valueField: 'ID',
                    displayField: 'DisplayName',
                    applyTo: 'PropertyComboBoxDiv'
                });

                var Pie1ButtonVar = new Ext.Button({
                    text: 'Set',
                    scale: 'small',
                    width: '40',
                    applyTo: 'Pie1ButtonDiv',
                    handler: function () {
                        if (Ext.isEmpty(PropertyComboBox.value)) {
                            Ext.Msg.show({
                                title: 'Warning',
                                msg: 'Please select a retrieved property',
                                buttons: Ext.Msg.OK,
                                icon: Ext.MessageBox.WARNING,
                                minWidth: 300
                            });
                            return;
                        }
                        document.getElementById('Pie1').value = PropertyComboBox.getRawValue();
                        document.getElementById('Pie1ID').value = PropertyComboBox.getValue();
						document.getElementById('Pie1').style.backgroundColor = "#FFFFBE";												
                        Ext.getCmp('ApplyButton').enable();
                    }
                }); // Button

                var Pie2ButtonVar = new Ext.Button({
                    text: 'Set',
                    scale: 'small',
                    width: '40',
                    applyTo: 'Pie2ButtonDiv',
                    handler: function () {
                        if (Ext.isEmpty(PropertyComboBox.value)) {
                            Ext.Msg.show({
                                title: 'Warning',
                                msg: 'Please select a retrieved property',
                                buttons: Ext.Msg.OK,
                                icon: Ext.MessageBox.WARNING,
                                minWidth: 300
                            });
                            return;
                        }
                        document.getElementById('Pie2').value = PropertyComboBox.getRawValue();
                        document.getElementById('Pie2ID').value = PropertyComboBox.getValue();
						document.getElementById('Pie2').style.backgroundColor = "#FFFFBE";											
                        Ext.getCmp('ApplyButton').enable();
                    }
                }); // Button
                
                var Pie3ButtonVar = new Ext.Button({
                    text: 'Set',
                    scale: 'small',
                    width: '40',
                    applyTo: 'Pie3ButtonDiv',
                    handler: function () {
                        if (Ext.isEmpty(PropertyComboBox.value)) {
                            Ext.Msg.show({
                                title: 'Warning',
                                msg: 'Please select a retrieved property',
                                buttons: Ext.Msg.OK,
                                icon: Ext.MessageBox.WARNING,
                                minWidth: 300
                            });
                            return;
                        }
                        document.getElementById('Pie3').value = PropertyComboBox.getRawValue();
                        document.getElementById('Pie3ID').value = PropertyComboBox.getValue();
						document.getElementById('Pie3').style.backgroundColor = "#FFFFBE";										
                        Ext.getCmp('ApplyButton').enable();
                    }
                }); // Button
                
				var PropertyCheckBoxGlobal = new Ext.form.Checkbox({
					id: 'PropertyCheckBoxGlobal',
					boxLabel: 'Global',
					checked: true,
					renderTo: 'CheckBoxGlobalDiv',
			        handler: function () {
							LoadComboBoxProperties();
			        }
				});

				var PropertyCheckBoxCustom = new Ext.form.Checkbox({
					id: 'PropertyCheckBoxCustom',					
					boxLabel: 'Custom',
					renderTo: 'CheckBoxCustomDiv',
			        handler: function () {
							LoadComboBoxProperties();
			        }
				});

				var PropertyCheckBoxAnalysis = new Ext.form.Checkbox({
					id: 'PropertyCheckBoxAnalysis',
					boxLabel: 'Analysis',
					renderTo: 'CheckBoxAnalysisDiv',
			        handler: function () {
							LoadComboBoxProperties();
			        }
				});
				
				var slider1Tip = new Ext.slider.Tip({
			        getText: function(thumb){
						if (thumb.value == 1)
				            return String.format('<b>{0} hour</b>', thumb.value);
						return String.format('<b>{0} hours</b>', thumb.value);
			        }
			    });

				var slider2Tip = new Ext.slider.Tip({
			        getText: function(thumb){
			            return String.format('<b>{0} days</b>', thumb.value);
			        }
			    });

			   var Pie4Slider1Var = new Ext.Slider({
			        renderTo: 'Pie4Slider1Div',
			        width   : 250,
			        minValue: 1,
			        maxValue: 72,
			        values  : [Pie41Saved, Pie42Saved],
			        plugins : slider1Tip
			    });

			   var Pie4Slider2Var = new Ext.Slider({
			        renderTo: 'Pie4Slider2Div',
			        width   : 250,
			        minValue: 3,
			        maxValue: 180,
			        values  : [Pie43Saved, Pie44Saved],
			        plugins : slider2Tip
			    });
				
				Pie4Slider1Var.on('changecomplete', function(slider, newValue, thumb) {
					var hourText = ' hours';
					if (thumb.value == 1)
						hourText = ' hour';
						
					if (thumb.index == 0) {
						document.getElementById('Pie4Value1').value = newValue + hourText;
						document.getElementById('Pie4Value1').style.backgroundColor = "#FFFFBE"
					}
					else if (thumb.index == 1) 
					{
						document.getElementById('Pie4Value2').value = newValue + hourText;
						document.getElementById('Pie4Value2').style.backgroundColor = "#FFFFBE"						
					}
                    Ext.getCmp('ApplyButton').enable();
				});

				Pie4Slider2Var.on('changecomplete', function(slider, newValue, thumb) {
					if (thumb.index == 0)
					{
	                    document.getElementById('Pie4Value3').value = newValue + ' days';
						document.getElementById('Pie4Value3').style.backgroundColor = "#FFFFBE"												
					}
					else if (thumb.index == 1)
					{
						document.getElementById('Pie4Value4').value = newValue + ' days';
						document.getElementById('Pie4Value4').style.backgroundColor = "#FFFFBE"																		
					}
                    Ext.getCmp('ApplyButton').enable();
				});
				
                document.getElementById('Pie1').value = (Pie1Saved.substring(Pie1Saved.indexOf('|') + 1));
                document.getElementById('Pie1ID').value = (Pie1Saved.substring(0, Pie1Saved.indexOf('|')));
                document.getElementById('Pie2').value = (Pie2Saved.substring(Pie2Saved.indexOf('|') + 1));
                document.getElementById('Pie2ID').value = (Pie2Saved.substring(0, Pie2Saved.indexOf('|')));
                document.getElementById('Pie3').value = (Pie3Saved.substring(Pie3Saved.indexOf('|') + 1));
                document.getElementById('Pie3ID').value = (Pie3Saved.substring(0, Pie3Saved.indexOf('|')));

				// Just being OCD - display 1 hour as singular, otherwise hours in plural
				if (Pie41Saved == 1)
	                document.getElementById('Pie4Value1').value = Pie41Saved + ' hour';
				else
					document.getElementById('Pie4Value1').value = Pie41Saved + ' hours';
					
                document.getElementById('Pie4Value2').value = Pie42Saved + ' hours';
                document.getElementById('Pie4Value3').value = Pie43Saved + ' days';
                document.getElementById('Pie4Value4').value = Pie44Saved + ' days';
            }

            ConfigWin.show(this);
        }
    }); // Button
    
	function LoadComboBoxProperties()
	{
		PropertyArrayForComboBoxCurrent = [];
		if (Ext.getCmp('PropertyCheckBoxGlobal').checked)
		{
			PropertyArrayForComboBoxCurrent = PropertyArrayForComboBoxCurrent.concat(PropertyArrayForComboBoxGlobal);
		}
		
		if (Ext.getCmp('PropertyCheckBoxCustom').checked)
		{
			PropertyArrayForComboBoxCurrent = PropertyArrayForComboBoxCurrent.concat(PropertyArrayForComboBoxCustom);
		}
		
		if (Ext.getCmp('PropertyCheckBoxAnalysis').checked)		
		{
			PropertyArrayForComboBoxCurrent = PropertyArrayForComboBoxCurrent.concat(PropertyArrayForComboBoxAnalysis);
		}
		// Load and update and Property combobox
		PropertyArrayForComboBoxCurrent.sort(sortByName);
		storeProp.loadData(PropertyArrayForComboBoxCurrent);
        Ext.getCmp('PropertyComboBox').setValue('');
	}
	
    var autoRunCheckBox = new Ext.form.Checkbox({
        boxLabel: 'Autorun',
        renderTo: 'autoRunCheckBoxDiv',
        handler: function () {
            // Save state of the checkbox as a cookie			
            cp.set('lw-asset-autoruncheckbox', this.checked);
        }
    });

    if (savedAutoRunCheckBox != 'None') {
        autoRunCheckBox.setValue(savedAutoRunCheckBox);
    }

    // This is the autorun part of the report. If the user checked "AutoRun", then create the dashboard right away
    if (autoRunCheckBox.getValue() == true) {
        GenerateDashboard();
    }

    //finally, remove the loading mask
    (function () {
        Ext.get('loading').fadeOut();
        Ext.get('loading-mask').fadeOut({
            remove: false
        });
    }).defer(250);

    function ParseCookie(Input, Item) {
        var PropName;
        var PropID1;
        var PropID2;
        var PropID3;

        if (Item == 'Name') {
            PropName = Input.substring(0, Input.indexOf('^'));
            return PropName;
        }
        else if (Item == 'SiteID') {
            PropID1 = Input.substring(Input.indexOf('^') + 1, Input.indexOf('|'));
            PropID1 = PropID1.substring(0, PropID1.indexOf(','));
            return PropID1;
        }
        else if (Item == 'AnalysisID') {
            PropID2 = Input.substring(Input.indexOf('^') + 1, Input.indexOf('|'));
            PropID2 = PropID2.substring(PropID2.indexOf(',') + 1, PropID2.lastIndexOf(','));
            return PropID2;
        }
        else if (Item == 'ItemID') {
            PropID3 = Input.substring(Input.indexOf('^') + 1, Input.indexOf('|'));
            PropID3 = PropID3.substring(PropID3.lastIndexOf(',') + 1);
            return PropID3;
        }
    }

    function GenerateDashboard() {
        if (Ext.isEmpty(comboFromArray2.value)) {
            Ext.Msg.show({
                title: 'Warning',
                msg: 'Please select computer groups',
                buttons: Ext.Msg.OK,
                icon: Ext.MessageBox.WARNING,
                minWidth: 300
            });
            return;
        }

        // Save info as cookies			
        cp.set('lw-asset-computer', comboFromArray2.getValue());

        if (comboFromArray2.getValue() == 'Custom Relevance Expression (0)') {
            cp.set('lw-asset-custom-computer', textAreaComputer.getValue());
        }

		if (Ext.isGecko == false) info('Generating dashboard, please wait...', 1000, 'filters', 100);

        var task = {
            run: function () {

				// The beginning of the session relevance statement to specify computers
		        computerFilter = 'elements of unions of (';

				// The computer groups can be multi-selected from the filter list. Use split() to retrieve the individual groups
				var computerFilterArray = new Array();
				computerFilterArray = comboFromArray2.value.split(',');

		        for (var i = 0; i < computerFilterArray.length; i++) {
				
					// Strip the computer count number behind the computer group name
					var computerGroup = computerFilterArray[i].substring(0, computerFilterArray[i].lastIndexOf(' ('));
					
					if (computerGroup == 'All Computers') {
						computerFilter = computerFilter + '(sets of bes computers whose (exists name of it))';
					}
					else if (computerGroup == 'All Windows Computers') {
						computerFilter = computerFilter + '(sets of bes computers whose (exists name of it and operating system of it as lowercase contains "win"))';
					}
					else if (computerGroup == 'Custom Relevance Expression') {
						computerFilter = computerFilter + '(sets of ' +  textAreaComputer.getValue() + ')';
						if (computerFilter == "") {
							Ext.Msg.show({
								title: 'Error in Session Relevance',
								msg: "Empty Session Relevance",
								buttons: Ext.Msg.OK,
								icon: Ext.MessageBox.ERROR,
								minWidth: 350
							});
							return;
						}
					}
					else {
						computerFilter = computerFilter + '(sets of members whose (exists name of it) of bes computer groups whose (name of it = "' + computerGroup + '"))';
					}
							
					if (i == computerFilterArray.length -1)
					{
						// This is the last and closing construct for the relevance statement
						computerFilter = computerFilter + ')';
					}
					else
					{
						// This adds the semicolon to separate the computer sets
						computerFilter = computerFilter + '; ';
					}
							
				} // end for loop

		        try {
					DefaultProperties = EvaluateRelevance(DefaultPropertiesRelevance);
		        }
		        catch (e) {
		            errMsg = '<b>Error:</b> ' + e.message + '<br/><br/><b>Statement:</b><br/> ' + DefaultPropertiesRelevance;

	                (function () {
	                    Ext.get('loading').fadeOut();
	                    Ext.get('loading-mask').fadeOut({
	                        remove: false
	                    });
	                }).defer(250);
		
		            Ext.Msg.show({
		                title: 'Error in Session Relevance',
		                msg: errMsg,
		                buttons: Ext.Msg.OK,
		                icon: Ext.MessageBox.ERROR,
		                minWidth: 350
		            });
		            Ext.TaskMgr.stopAll();
		        }

                var Pie1Saved = cp.get('lw-asset-pie1', DefaultProperties[0]);
                var Pie2Saved = cp.get('lw-asset-pie2', DefaultProperties[1]);
                var Pie3Saved = cp.get('lw-asset-pie3', DefaultProperties[2]);
				
                var relevanceStatementPie1 = '(it as string) of number of values of results from (' + computerFilter + ') of (bes property whose (item 0 of id of it =' + ParseCookie(Pie1Saved, 'SiteID') + ' and item 1 of id of it =' + ParseCookie(Pie1Saved, 'AnalysisID') + ' and item 2 of id of it =' + ParseCookie(Pie1Saved, 'ItemID') + '));' + '(multiplicity of it as string & "|" & it) of ' + 'unique values of values of results from (' + computerFilter + ') of (bes property whose (item 0 of id of it =' + ParseCookie(Pie1Saved, 'SiteID') + ' and item 1 of id of it =' + ParseCookie(Pie1Saved, 'AnalysisID') + ' and item 2 of id of it =' + ParseCookie(Pie1Saved, 'ItemID') + '))';
				
				if (Ext.isGecko == true)
				{
                	Ext.get('loading').show();
                	Ext.get('loading-mask').show();					
				}

                document.getElementById('loading-indicator').innerHTML = 'Loading ' + ParseCookie(Pie1Saved, 'Name') + '...';
                buildPie('hc-panel-pie1', ParseCookie(Pie1Saved, 'Name'), ParseCookie(Pie1Saved, 'Name'), relevanceStatementPie1, true);

                var relevanceStatementPie2 = '(it as string) of number of values of results from (' + computerFilter + ') of (bes property whose (item 0 of id of it =' + ParseCookie(Pie2Saved, 'SiteID') + ' and item 1 of id of it =' + ParseCookie(Pie2Saved, 'AnalysisID') + ' and item 2 of id of it =' + ParseCookie(Pie2Saved, 'ItemID') + '));' + '(multiplicity of it as string & "|" & it) of ' + 'unique values of values of results from (' + computerFilter + ') of (bes property whose (item 0 of id of it =' + ParseCookie(Pie2Saved, 'SiteID') + ' and item 1 of id of it =' + ParseCookie(Pie2Saved, 'AnalysisID') + ' and item 2 of id of it =' + ParseCookie(Pie2Saved, 'ItemID') + '))';
                document.getElementById('loading-indicator').innerHTML = 'Loading ' + ParseCookie(Pie2Saved, 'Name') + '...';
                buildPie('hc-panel-pie2', ParseCookie(Pie2Saved, 'Name'), ParseCookie(Pie2Saved, 'Name'), relevanceStatementPie2, true);

                var relevanceStatementPie3 = '(it as string) of number of values of results from (' + computerFilter + ') of (bes property whose (item 0 of id of it =' + ParseCookie(Pie3Saved, 'SiteID') + ' and item 1 of id of it =' + ParseCookie(Pie3Saved, 'AnalysisID') + ' and item 2 of id of it =' + ParseCookie(Pie3Saved, 'ItemID') + '));' + '(multiplicity of it as string & "|" & it) of ' + 'unique values of values of results from (' + computerFilter + ') of (bes property whose (item 0 of id of it =' + ParseCookie(Pie3Saved, 'SiteID') + ' and item 1 of id of it =' + ParseCookie(Pie3Saved, 'AnalysisID') + ' and item 2 of id of it =' + ParseCookie(Pie3Saved, 'ItemID') + '))';
                document.getElementById('loading-indicator').innerHTML = 'Loading ' + ParseCookie(Pie3Saved, 'Name') + '...';
                buildPie('hc-panel-pie3', ParseCookie(Pie3Saved, 'Name'), ParseCookie(Pie3Saved, 'Name'), relevanceStatementPie3, true);

				Pie41Saved = cp.get('lw-asset-pie41', '1');
				Pie42Saved = cp.get('lw-asset-pie42', '24');
				Pie43Saved = cp.get('lw-asset-pie43', '7');
				Pie44Saved = cp.get('lw-asset-pie44', '30');

                var relevanceStatementLastReportTime = 
					'substrings separated by ";" of ' + 
					'(number of results from (' + computerFilter + ') of it as string & ";" &  ' + 
					' number of results from (' + computerFilter + ') whose (now - (value of it as time) < ' + Pie41Saved + ' * hour) of it as string & "|Within ' + Pie41Saved + ' hours;" &  ' + 
					' number of results from (' + computerFilter + ') whose (now - (value of it as time) > ' + Pie41Saved + ' * hour and now - (value of it as time) < ' + Pie42Saved + ' * hour) of it as string & "|Within ' + Pie42Saved + ' hours;" &  ' + 
					' number of results from (' + computerFilter + ') whose (now - (value of it as time) > ' + Pie42Saved + ' * hour  and now - (value of it as time) < ' + Pie43Saved + ' * day) of it as string & "|Within ' + Pie43Saved + ' days;" &  ' + 
					' number of results from (' + computerFilter + ') whose (now - (value of it as time) > ' + Pie43Saved + ' * day  and now - (value of it as time) < ' + Pie44Saved + ' * day) of it as string & "|Within ' + Pie44Saved + ' days;" &  ' + 
					' number of results from (' + computerFilter + ') whose (now - (value of it as time) > ' + Pie44Saved + ' * day) of it as string & "|More than ' + Pie44Saved + ' days")  ' + 'of (bes property "Last Report Time") ';
								
                document.getElementById('loading-indicator').innerHTML = 'Loading Last Report Time...';
                buildPie('hc-panel-pie4', 'Last Report Time', 'Last Report Time', relevanceStatementLastReportTime, false);

                document.getElementById('loading-indicator').innerHTML = 'Populating Computer Grid...';
                PopulateComputerGrid('ShowFilterComputers', null, null, null);
                if (comboFromArray2.value == 'Custom Relevance Expression (0)') {
					activeComputerGroup = 'Computers from Custom Relevance Expression';
				}
				else {
					activeComputerGroup = comboFromArray2.value;
				}
				
				// Title for the grid panel. If too long, trim it for aesthetics 
				var gridPanelTitle = activeComputerGroup;
				if (activeComputerGroup.length > gridPanelTitleLength)
					gridPanelTitle = activeComputerGroup.substring(0, gridPanelTitleLength) + '..';

				gridComputer.setTitle(gridPanelTitle);

				var CurrentTime = new Date();
                document.getElementById('TimeStampDiv').innerHTML = CurrentTime.format('M jS, Y g:iA T');
				
                (function () {
                    Ext.get('loading').fadeOut();
                    Ext.get('loading-mask').fadeOut({
                        remove: false
                    });
                }).defer(250);

            },
            interval: 50,
            repeat: 1
        };

        Ext.TaskMgr.start(task);
    }

    // Pie Chart ---------------------------------------------------------------------------------------------------------------------------------------------------------
    function buildPie(displayDiv, panelTitle, chartTitle, relevanceStatement, sortSwitch) {

        var relevanceLocal = relevanceStatement;
		var panelTitleLocal = panelTitle;
		var chartTitleLocal = chartTitle;
		if (panelTitle.length > 35)
			panelTitleLocal = panelTitle.substring(0, 35) + '..';
		
		if (chartTitle.length > 35)
			chartTitleLocal = chartTitle.substring(0, 35) + '..';
		
		var relevanceResults;
		
        try {
            relevanceResults = EvaluateRelevance(relevanceLocal);
        }
        catch (e) {
            if (textAreaComputer.getValue() == '' || textAreaComputer.getValue() == 'Session Relevance returning Computers') {
				errMsg = '<b>Error:</b> The relevance statement is empty';
			}
			else {
				errMsg = '<b>Error:</b> ' + e.message + '<br/><br/><b>Statement:</b><br/> ' + relevanceLocal;
			}

            (function () {
                Ext.get('loading').fadeOut();
                Ext.get('loading-mask').fadeOut({
                    remove: false
                });
            }).defer(250);

            Ext.Msg.show({
                title: 'Error in Session Relevance',
                msg: errMsg,
                buttons: Ext.Msg.OK,
                icon: Ext.MessageBox.ERROR,
                minWidth: 350
            });

            Ext.TaskMgr.stopAll();
        }

        var rawData = new Array();

        var totalNumber = relevanceResults[0];
        var topHowMany = 10;
        relevanceResults = relevanceResults.slice(1, relevanceResults.length);

        for (var i = 0; i < relevanceResults.length; i++) {
            var row = new Array();
            // This is the string value
            var name = relevanceResults[i].substring(relevanceResults[i].indexOf('|') + 1);
            var count = parseInt(relevanceResults[i].substring(0, relevanceResults[i].indexOf('|')));
            var percent = (count / totalNumber);
            row[1] = name + ' (' + count + ')';
            row[0] = percent;
            row[2] = count;
            rawData[i] = row;
        }
        if (sortSwitch) rawData.sort(sortByNum);

        var countOthers = 0;

        if (rawData.length > 10) {
            for (var k = topHowMany; k < rawData.length; k++) {
                countOthers = countOthers + parseInt(rawData[k][2]);
            }
            rawData = rawData.slice(0, topHowMany);
        }

        var PieData = new Array();

        for (var j = 0; j < rawData.length; j++) {
            PieData[j] = [rawData[j][1], rawData[j][0]];
        }

        if (relevanceResults.length > 10) PieData[topHowMany] = ['Others (' + countOthers + ')', countOthers / totalNumber];

        function sortByNum(a, b) {
            var x = a[0];
            var y = b[0];
            return x == y ? 0 : (x < y ? 1 : -1)
        }

        colorArray = new Array();
        if (sortSwitch) {
            // This color array is geared towards a wide spread of colors for aesthetics
            colorArray = ['#4572A7', '#AA4643', '#89A54E', '#80699B', '#3D96AE', '#DB843D', '#92A8CD', '#A47D7C', '#B5CA92', '#EFD279', '#A8B1B8'];
        }
        else {
            // This color array uses a gradient from green to red to denote good to bad
			// Don't change this because the color values are being used to identify the slice being clicked on later
            colorArray = ['#89A54E', '#B5CA92', '#EFD279', '#DB843D', '#AA4643'];
        }

		var chartMessage = false;
		
		if (PieData.length == 0)
			chartMessage = true;
			
		var panelIcon = 'chart-pie';
		if (panelTitle == 'Last Report Time')
			panelIcon = 'icon-time';
			
        // Pie Chart -----------------------------------------------------------------------------------------------------------------------------------------------------		
        var PieChart = new Ext.ux.HighchartPanel({
			id: 'MyChart',
            layout: 'fit',
            iconCls: panelIcon,
            collapsible: true,
            applyTo: displayDiv,
            title: panelTitleLocal,
            width: 348,
            height: 250,
            chartConfig: {
                colors: colorArray,
                chart: {
                    margin: [30, 160, 1, 1]
                    // backgroundColor: '#efefef'
                },
                credits: {
                    enabled: chartMessage,
					text: 'No data',
					href: 'http://support.bigfix.com',
					target: '_blank'
                },
                title: {
                    text: chartTitleLocal
                },
                plotArea: {
                    shadow: null,
                    borderWidth: null,
                    backgroundColor: null
                },
                tooltip: {
                    formatter: function () {
                        var percent = parseFloat(this.y) * 100;
                        return '<b>' + this.point.name + '</b>: ' + percent.toFixed(2) + '%';
                    }
                },
                plotOptions: {
                    pie: {
                        allowPointSelect: false,
                        point: {
                            events: {
                                legendItemClick: function (event) {

                                    if (Ext.isIE == true) info('Retrieve computer info...', 1000, 'filters', 100);

                                    var w = Ext.getCmp('gridComputer');
                                    w.getEl().mask('Loading...');
									
                                    // PopulateComputerGrid(Mode, RetrievePropertyName, RetrievePropertyValue, WhoseClause);
                                    if (panelTitle == 'Last Report Time') {
										
										Pie41Saved = cp.get('lw-asset-pie41', '1');
										Pie42Saved = cp.get('lw-asset-pie42', '24');
										Pie43Saved = cp.get('lw-asset-pie43', '7');
										Pie44Saved = cp.get('lw-asset-pie44', '30');
										
                                        var whoseClause;
                                        if (this.color == '#89A54E') {
                                            whoseClause = 'whose (now - (value of it as time) < ' + Pie41Saved + ' * hour)';
                                        }
                                        else if (this.color == '#B5CA92') {
                                            whoseClause = 'whose (now - (value of it as time) > ' + Pie41Saved + ' * hour and now - (value of it as time) < ' + Pie42Saved + ' * hour)';
                                        }
                                        else if (this.color == '#EFD279') {
                                            whoseClause = 'whose (now - (value of it as time) > ' + Pie42Saved + ' * hour  and now - (value of it as time) < ' + Pie43Saved + ' * day)';
                                        }
                                        else if (this.color == '#DB843D') {
                                            whoseClause = 'whose (now - (value of it as time) > ' + Pie43Saved + ' * day and now - (value of it as time) < ' + Pie44Saved + ' * day)';
                                        }
                                        else if (this.color == '#AA4643') {
                                            whoseClause = 'whose (now - (value of it as time) > ' + Pie44Saved + ' * day)';
                                        }

                                        PopulateComputerGrid('ShowLastReportTime', panelTitle, null, whoseClause);
                                        gridComputer.setTitle(panelTitle + ' - ' + this.name.substring(0, this.name.lastIndexOf(' (')));
                                    }
                                    else if (this.name.substring(0, this.name.lastIndexOf(' (')) == 'Others') {
                                        var whoseClause = 'values whose (';
                                        var oneItem;
                                        for (var i = 0; i < PieData.length - 2; i++) {
                                            oneItem = PieData[i][0];
                                            oneItem = oneItem.substring(0, oneItem.lastIndexOf(' ('));
                                            whoseClause = whoseClause + 'it != "' + oneItem + '" and '
                                        }
                                        oneItem = PieData[PieData.length - 2][0];
                                        oneItem = oneItem.substring(0, oneItem.lastIndexOf(' ('));
                                        whoseClause = whoseClause + 'it != "' + oneItem + '") of it';
                                        PopulateComputerGrid('ShowRetrievedPropertyOtherComputers', panelTitle, this.name.substring(0, this.name.lastIndexOf(' (')), whoseClause);
                                        gridComputer.setTitle(panelTitle + ' - ' + this.name.substring(0, this.name.lastIndexOf(' (')));
                                    }
                                    else {
                                        PopulateComputerGrid('ShowRetrievedPropertyComputers', panelTitle, this.name.substring(0, this.name.lastIndexOf(' (')), null);
										var panelTitleLocal = panelTitle + ' - ' + this.name.substring(0, this.name.lastIndexOf(' ('));
										if (panelTitleLocal.length > 35)
										{
											gridComputer.setTitle('..' + this.name.substring(0, this.name.lastIndexOf(' (')));
										}
										else
										{
	                                        gridComputer.setTitle(panelTitle + ' - ' + this.name.substring(0, this.name.lastIndexOf(' (')));										
										}
                                    }
									
                                    event.preventDefault();

                                    w.getEl().unmask();

                                }
                            }
                        },
                        dataLabels: {
                            enabled: true,
                            formatter: function () {
                                if (this.y > 0.12) {
                                    if (this.point.name.length < 20) {
                                        return '<font style="font-size: xx-small;"><center>' + this.point.name.substring(0, this.point.name.lastIndexOf('(')) + '<br>' + (parseFloat(this.y) * 100).toFixed(2) + '%</center></font>';
                                    }
                                    else {
                                        var substringVar = this.point.name.substring(0, this.point.name.lastIndexOf('('));
                                        substringVar = substringVar.substring(0, 15);
                                        return '<font style="font-size: xx-small;"><center>' + substringVar + '..<br>' + (parseFloat(this.y) * 100).toFixed(2) + '%</center></font>';
                                    }
                                }
                            },
                            color: '#37414A',
                            style: {
                                font: '13px Trebuchet MS, Verdana, sans-serif'
                            }
                        }
                    }
                },
                legend: {
                    layout: 'vertical',
                    style: {
                        left: 'auto',
                        bottom: 'auto',
                        right: '1px',
                        top: '30px'
                    },
                    labelFormatter: function () {
                        if (this.name.length > 20) {
                            var countVar = this.name.substring(this.name.lastIndexOf('('));
                            var substringVar = this.name.substring(0, 20 - 2 - countVar.length);
                            return '<font style="font-size: xx-small;">' + substringVar + '..' + countVar + '</font>';
                        }
                        else {
                            return '<font style="font-size: xx-small;">' + this.name + '</font>';
                        }
                    }
                },
                series: [{
                    type: 'pie',
                    name: panelTitleLocal,
                    data: PieData
                }]
            }
        });
		
    }

	var pStore;
	var pStore2;
	
    // Computer grid -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------	

    function PopulateComputerGrid(Mode, RetrievedPropertyName, RetrievedPropertyValue, WhoseClause) {

        pStore2 = new Ext.data.ArrayStore({
            fields: [{
                name: 'ComputerID'
            },
            {
                name: 'ComputerName'
            },
            {
                name: 'OperatingSystem'
            },
            {
                name: 'IPAddress'
            },
            {
                name: 'LastReportTime'
            }]
        });

        pStore = new Ext.ux.data.PagingArrayStore({
            fields: [{
                name: 'ComputerID'
            },
            {
                name: 'ComputerName'
            },
            {
                name: 'OperatingSystem'
            },
            {
                name: 'IPAddress'
            },
            {
                name: 'LastReportTime'
            }],
            lastOptions: {
                params: {
                    start: 0,
                    limit: 18
                }
            }
        });

        // Session Relevance
        if (Mode == 'ShowFilterComputers') {
            var relevanceComputer = '(id of it as string & "||" & ' + '("<A name=%22" & name of it & "%22 href=%22" & link href of it & "%22 target=%22_blank%22>" & name of it & "</A>") & "||" & ' + '(if (exists operating system of it) then (operating system of it) else ("Unknown")) & "||" &  ' + '(if (exists ip addresses of it) then (concatenation ("<br /> ") of (ip addresses of it as string)) else (" ")) & "||" & ' + '((year of it as string & "/" & month of it as two digits & "/" & day_of_month of it as two digits) of  date(local time zone) of it & " "& (two digit hour of it as string & ":" & two digit minute of it as string & ":" & two digit second of it as string) of time (local time zone) of it) of last report time of it ' + ') of ' + computerFilter;
        }
        else if (Mode == 'ShowRetrievedPropertyComputers') {
			var relevanceComputer = '(id of item 1 of it as string & "||" & ("<A name=%22" & name of item 1 of it & "%22 href=%22" & link href of item 1 of it & "%22 target=%22_blank%22>" & name of item 1 of it & "</A>") & "||" & (if (exists operating system of item 1 of it) then (operating system of item 1 of it) else ("Unknown")) & "||" & (if (exists ip addresses of item 1 of it) then (concatenation ("<br /> ") of (ip addresses of item 1 of it as string)) else (" ")) & "||" & ((year of it as string & "/" & month of it as two digits & "/" & day_of_month of it as two digits) of  date(local time zone) of it & " "& (two digit hour of it as string & ":" & two digit minute of it as string & ":" & two digit second of it as string) of time (local time zone) of it) of last report time of item 1 of it) of (values whose (it = "' + RetrievedPropertyValue + '") of it, computer of it) of results (' + computerFilter + ', bes property "' + RetrievedPropertyName + '")';
        }
        else if (Mode == 'ShowRetrievedPropertyOtherComputers') {
			var relevanceComputer = 'unique values of (id of item 1 of it as string & "||" & ("<A name=%22" & name of item 1 of it & "%22 href=%22" & link href of item 1 of it & "%22 target=%22_blank%22>" & name of item 1 of it & "</A>") & "||" & (if (exists operating system of item 1 of it) then (operating system of item 1 of it) else ("Unknown")) & "||" & (if (exists ip addresses of item 1 of it) then (concatenation ("<br /> ") of (ip addresses of item 1 of it as string)) else (" ")) & "||" & ((year of it as string & "/" & month of it as two digits & "/" & day_of_month of it as two digits) of  date(local time zone) of it & " " & (two digit hour of it as string & ":" & two digit minute of it as string & ":" & two digit second of it as string) of time (local time zone) of it) of last report time of item 1 of it) of (' + WhoseClause + ' , computer of it) of results (' + computerFilter + ', bes property "' + RetrievedPropertyName + '")';
        }
        else if (Mode == 'ShowLastReportTime') {
            var relevanceComputer = '(id of computer of it as string & "||" &' + ' ("<A name=%22" & name of computer of it & "%22 href=%22" & link href of computer of it & "%22 target=%22_blank%22>" & name of computer of it & "</A>") & "||" &' + '(if (exists operating system of computer of it) then (operating system of computer of it) else ("Unknown")) & "||" & ' + '(if (exists ip addresses of computer of it) then (concatenation ("<br /> ") of (ip addresses of computer of it as string)) else (" ")) & "||" &' + '((year of it as string & "/" & month of it as two digits & "/" & day_of_month of it as two digits) of  date(local time zone) of it & " "& (two digit hour of it as string & ":" & two digit minute of it as string & ":" & two digit second of it as string) of time (local time zone) of it) of last report time of computer of it' + ') of results (' + computerFilter + ', bes property "' + RetrievedPropertyName + '") ' + WhoseClause;
        }

        try {
            var resultsComputers = EvaluateRelevance(relevanceComputer);
        }
        catch (e) {
            errMsg = '<b>Error:</b> ' + e.message + '<br/><br/><b>Statement:</b><br/> ' + relevanceComputer;

            Ext.Msg.show({
                title: 'Error in Session Relevance',
                msg: errMsg,
                buttons: Ext.Msg.OK,
                icon: Ext.MessageBox.ERROR,
                minWidth: 350
            });
            Ext.TaskMgr.stopAll();
        }

        var dataArray = new Array();
        var dataOneRow = [];

        for (var i = 0; i < resultsComputers.length; i++) {
            dataOneRow = resultsComputers[i].split('||');
            dataArray[i] = dataOneRow;
        }

		dataArray.sort(sortByName);
		
        // manually load local data
        pStore.loadData(dataArray);
		pStore2.loadData(dataArray);
		
		if (Mode == 'ShowFilterComputers') {
			allComputers = pStore;
		}

        // create the Grid ----------------------------------------------------------------------------------------------------------------------------------------------
		if (!gridComputer)
		{
	        gridComputer = new Ext.grid.GridPanel({
            id: 'gridComputer',
            iconCls: 'icon-computer',
            store: pStore,
            columns: [{
                id: 'ComputerID',
                header: 'Computer ID',
                sortable: true,
                width: 100,
                dataIndex: 'ComputerID',
                hidden: true
            },
            {
                header: 'Computer',
                sortable: true,
                width: 100,
                dataIndex: 'ComputerName'
            },
            {
                header: 'Operating System',
                sortable: true,
                width: 100,
                dataIndex: 'OperatingSystem'
            },
            {
                header: 'IP Address',
                sortable: true,
                width: 100,
                dataIndex: 'IPAddress',
                hidden: true
            },
            {
                header: 'Last Report Time',
                sortable: true,
                width: 140,
                dataIndex: 'LastReportTime'
            }],
            stripeRows: true,
            height: 508,
            // width: 350,
            width: 350,
            title: 'Computers',
            collapsible: true,
            animCollapse: false,
            renderTo: 'ComputerDrillDownDiv',
            stateful: true,
            stateId: 'grid',
            loadMask: {
                msg: 'Loading...'
            },

            // paging bar on the bottom
            bbar: new Ext.PagingToolbar({
                pageSize: 18,
                store: pStore,
                displayInfo: true,
                displayMsg: '{0} - {1} of {2}',
                emptyMsg: "No computers to display"
            }),
            tbar: new Ext.Toolbar({
                items: [{
                    xtype: 'tbfill'
                },
                {
                    xtype: 'tbbutton',
                    iconCls: 'icon-monitor',
                    text: 'Show All',
                    scale: 'small',
                    handler: function () {
			            var gp = Ext.getCmp('gridComputer');
						gp.getEl().mask('Loading...')
						var myColumnModel = gp.getColumnModel();

						gp.reconfigure(allComputers, myColumnModel);
						gp.getBottomToolbar().bind(allComputers);

						// Title for the grid panel. If too long, trim it for aesthetics 
						var gridPanelTitle = activeComputerGroup;
						if (activeComputerGroup.length > gridPanelTitleLength)
							gridPanelTitle = activeComputerGroup.substring(0, gridPanelTitleLength) + '..';
								
						gp.setTitle(gridPanelTitle);
						
			            gp.getEl().unmask();

						if (Mode == 'ShowFilterComputers') {
							pStore2.loadData(dataArray);
						}

                    }
                },
                {
                    xtype: 'tbseparator'
                },
                {
                    xtype: 'tbbutton',
                    iconCls: 'icon-excel',
                    text: 'Excel',
                    scale: 'small',
                    handler: function () {

                        if (Ext.isGecko == false && Ext.isSafari == false) {
                            Ext.Msg.show({
                                title: 'Sorry!',
                                msg: 'The export to Excel function is only available in FireFox or Safari',
                                buttons: Ext.Msg.OK,
                                icon: Ext.MessageBox.INFO,
                                minWidth: 300
                            });
                            return;
                        }

                        info('Generating data for Excel...', 2000, 'filters', 200);

                        document.getElementById('footer').innerHTML = '';

                        var newColumnModel = gridComputer.getColumnModel();
						
                        // For the purpose of exporting, we have expanded the grid with full data
                        gridComputer.reconfigure(pStore2, newColumnModel);

                        var exportButton = new Ext.ux.Exporter.Button({
                            name: 'excelLinkButton',
                            id: 'excelLinkButton',
                            text: '.',
                            component: gridComputer,
                            renderTo: 'footer',
                            store: pStore2
                        });
                        // This is a very convoluted way of doing Excel export
                        // The library that I use puts the functionality in a button.
                        // However, the buttons needs to be dynamically generated to associate 
                        // the latest set of data.				        
                        // window.open(exportButton.getEl().child('a', true).href, "name");
                        window.location.href = exportButton.getEl().child('a', true).href;

                        // Put the grid back to its original state with paging
                        gridComputer.reconfigure(pStore, newColumnModel);
                    }
                }]
            })
        });
		}
		else
		{
			// This section reuses the grid is already created
            var gp = Ext.getCmp('gridComputer');
			var myColumnModel = gp.getColumnModel();
			gp.reconfigure(pStore, myColumnModel);
			gp.getBottomToolbar().bind(pStore);
            gp.getEl().unmask();
		}

    } // end of PopulateComputerGrid() function

    function info(msg, timeout, div, offsetY) {
        new Ext.ux.window.MessageWindow({
            title: 'Message:',
            html: msg || 'No information available',
            origin: {
                el: Ext.get(div),
                //element to align to 
                offX: -0.5 * Ext.get(div).getWidth(),
                //amount to offset horizontally
                offY: offsetY
            },
            autoHeight: true,
            resizable: true,
            minWidth: 230,
            pinOnClick: false,
            iconCls: 'icon-info',
            help: false,
            hideFx: {
                delay: timeout,
                mode: 'standard'
            }
        }).show(Ext.getDoc());
    } //function info()

    function sortByName(a, b) {
        var x = a[1];
        var y = b[1];
        return x == y ? 0 : (x < y ? -1 : 1)
    }
    
});
