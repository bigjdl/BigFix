 /* 
 
 Fixlet Compliance by Computer Group report
 
 Created by Lee Wei
 Last updated December 3rd, 2015
 Version 1.7
 See BigFix forum post for additional information
 https://forum.bigfix.com/t/report-available-fixlet-compliance-by-computer-group/6165
 
*/ 

Ext.BLANK_IMAGE_URL = '/ext-3.2.0/resources/images/default/s.gif';

Ext.onReady(function () {

    Ext.QuickTips.init();

    var cp = new Ext.state.CookieProvider({
        path: "/",
        expires: new Date(new Date().getTime() + (1000 * 60 * 60 * 24 * 30)) //30 days
    });

    Ext.state.Manager.setProvider(cp);

    var xg = Ext.grid;
    var myChartData = [];
    var totalApplicableFixlets = 0;
    var totalInstalledFixlets = 0;
    var totalOutstandingFixlets = 0;
    var compliancePercentage = 0;
    var complianceHTML = '';
    var complianceLegendHTML = '';
    var customFixletText = 'Session Relevance returning Fixlets';
    var customComputerText = 'Session Relevance returning Computers';

    var totalRelevantFixlets = 0;
    var totalComputers = 0;
    var diplayedRelevantFixlets = 1000;
	
	var win;  // Message window

	var comboFromArray1;
	var comboFromArray2;
	
	// How to treat Fixlets with no computers applicable. Values should be 0, 100, or -99 for not applicable
	var valueForZeroApplicable = -99; 

    // Filter Panel ------------------------------------------------------------------------------------------------------------------------------------------------------
    var FiltersPanel = new Ext.Panel({
        iconCls: 'icon-filter',
        title: 'Filters (v1.7)',
        renderTo: 'filters',
        width: 1000,
        layout: 'absolute',
        collapsible: true,
        bodyStyle: {
            background: '#cedff5',
            padding: '10px'
        },
        html: 
			'<table><tr>' + 
				'<td><div class="lw-label">Content:&nbsp;</div></td>' + 
				'<td><div id="baselineDiv"><input class="lw-combo" type="text" id="baseline" size="40" /></div></td>' + 
				'<td><div class="lw-label" style="margin-left: 10px">Computer&nbsp;Group:&nbsp;</div></td>' + 
				'<td><div><input class="lw-combo" type="text" id="computerGroup" size="40"/></div></td>' + 
			'</tr>' + '<tr>' + 
				'<td></td>' + 
				'<td style="vertical-align:top;"><div id="customFixletDiv"></div></td>' + 
				'<td></td>' + 
				'<td style="vertical-align:top;"><div id="customComputerDiv" ></div></td>' + 
			'</tr>' + 
			'</table>',        
		tbar: new Ext.Toolbar({
            items: [{
                xtype: 'tbfill'
            },
            {
                xtype: 'tbseparator'
            },
			{
				xtype: 'tbbutton',
				iconCls: 'icon-generate',
				text: 'Generate Report',
				tooltip: '<b>If you have a lot of data, this can take a while</b><br/>Click on Important Information button to see some helpful performance hints',
				scale: 'small',
				handler: function(){
				
					if (Ext.isEmpty(comboFromArray1.value) || (comboFromArray1.value.substring(0, 1) == 'X' && comboFromArray1.value.split(',').length == 1)) {
						// if (Ext.isEmpty(comboFromArray1.value)) {
						Ext.Msg.show({
							title: 'Warning',
							msg: 'Please select content',
							buttons: Ext.Msg.OK,
							icon: Ext.MessageBox.WARNING,
							minWidth: 300
						});
						return;
					}
					else 
						if (Ext.isEmpty(comboFromArray2.value)) {
							Ext.Msg.show({
								title: 'Warning',
								msg: 'Please select a computer group',
								buttons: Ext.Msg.OK,
								icon: Ext.MessageBox.WARNING,
								minWidth: 300
							});
							return;
						}
					
					// Save info as cookies			
					cp.set('lw-cb-fixlet', comboFromArray1.getValue());
					cp.set('lw-cb-computer', comboFromArray2.getValue());
					
					if (comboFromArray1.getValue() == 'R||Custom Relevance Expression||0') {
						cp.set('lw-custom-fixlet', textAreaFixlet.getValue());
					}
					
					if (comboFromArray2.getValue() == 'Custom Relevance Expression (0)') {
						cp.set('lw-custom-computer', textAreaComputer.getValue());
					}
					
					info('Running report, please wait...', 1000, 'filters', 100);
					
					var task = {
						run: function(){
							buildGrid();
							buildChart();
						},
						interval: 50,
						repeat: 1
					};
					
					Ext.TaskMgr.start(task);
				}
			},  // Button
            {
                xtype: 'tbseparator'
            },
			{
				xtype: 'tbbutton',
				iconCls: 'icon-script-edit',
				text: 'Edit Custom Relevance',
				tooltip: '<b>Show or Hide Relevance text box</b><br/>The relevances entered are used by the selection Custom Session Relevance in the filter list',
				scale: 'small',
				handler: function(){
		            var divCustomFixlet = document.getElementById('customFixletDiv');
		            var divCustomComputer = document.getElementById('customComputerDiv');
		
		            if (this.getText() == 'Edit Custom Relevance') {
						this.setText('Hide Custom Relevance');
		                divCustomFixlet.style.display = 'block';
		                textAreaFixlet.setValue(customFixletText);
		
		                divCustomComputer.style.display = 'block';
		                textAreaComputer.setValue(customComputerText);
		            } else {
						this.setText('Edit Custom Relevance');
		                customFixletText = textAreaFixlet.getValue();
		                divCustomFixlet.style.display = 'none';
		
		                customComputerText = textAreaComputer.getValue();
		                divCustomComputer.style.display = 'none';
		            }	
				}
            },
            {
                xtype: 'tbseparator'
            },
            {
                xtype: 'tbbutton',
				iconCls: 'icon-info',
				text: 'Important Information',
				tooltip: '<b>Important Information</b><br/>Please read some potentially useful information about using this report',
				handler: 	function()
				{				
			        // create the window on the first click and reuse on subsequent clicks
			        if(!win){
			            win = new Ext.Window({
			                applyTo:'help-win',
			                // layout:'fit',
							layout:'absolute',
							x: 260, 
							y: 100,
			                width:500,
			                height:400,
			                closeAction:'hide',
			                plain: false,
			                items: new Ext.Panel({
			                    applyTo: 'help-tab',
								autoScroll: true,
			                    autoTabs:true,
			                    activeTab:0,
			                    deferredRender:false,
			                    border:false,
								html: showFlagHTML
			                }),
			                buttons: [{
			                    text: 'Close',
			                    handler: function(){
			                        win.hide();
			                    }
			                }]
			            });
			        }
			        win.show(this);
			    }            
			},
            {
                xtype: 'tbseparator'
            }]
		})
    });

	// A bunch of requirement testing ----------------------------------------------------------------------------------------------------------------------------------------
	
	var showFlag = false;
	var missingFlash = false;
	var noExcel = false;
	var isIE = false;
	var isGecko = false;
	var showFlagHTML = '';
	
	// Globals
	// Major version of Flash required
	var requiredMajorVersion = 9;
	// Minor version of Flash required
	var requiredMinorVersion = 0;
	// Minor version of Flash required
	var requiredRevision = 0;
	
	var hasReqestedVersion = DetectFlashVer(requiredMajorVersion, requiredMinorVersion, requiredRevision);

	// Check to see if the version meets the requirements for chart playback
	if (hasReqestedVersion) {
		// All good
	} else {  // flash is too old or we can't detect the plugin
		showFlag = true;
		missingFlash = true;
				
		showFlagHTML += '<div class="x-panel-body" style="padding:15px;">';
		showFlagHTML += '<div style="float:left"><img src="/ext-3.2.0/resources/images/default/shared/warning.gif"></div>';
		showFlagHTML += '<div style="float:left; margin-left:10px;"><p><h2>Missing Adobe Flash Player</h2></p>';
		showFlagHTML += '<p>Flash is required to display the charts. The report will run, but the chart panels will be empty.</p>';
		showFlagHTML += '<p>Flash can be downloaded from Adobe <a href="http://get.adobe.com/flashplayer/" target="_blank">here.</a></p></div></div>';
	}

	if (Ext.isGecko3 == false)
	{
		showFlag = true;
		noExcel = true;
		showFlagHTML += '<div class="x-panel-body" style="padding:15px;">';
		showFlagHTML += '<div style="float:left"><img src="/ext-3.2.0/resources/images/default/shared/warning.gif"></div>';
		showFlagHTML += '<div style="float:left; margin-left:10px;"><p><h2>Cannot export to Excel</h2></p>';
		showFlagHTML += '<p>The export to Excel function is only available in FireFox 3.x.</p>';
		showFlagHTML += '<p>FireFox can be download from the Mozilla project <a href="http://www.mozilla.com/en-US/products/download.html" target="_blank">here.</a></p>';
		showFlagHTML += '</div></div>';
	}

	if (Ext.isIE == true)
	{
		showFlag = true;
		isIE = true;

		showFlagHTML += '<div class="x-panel-body" style="padding:15px;"> ';
		showFlagHTML += '<div style="float:left"><img src="/ext-3.2.0/resources/images/default/shared/warning.gif"></div>';
		showFlagHTML += '<div style="float:left; margin-left:10px;"><p><h2>Internet Explorer "Stop running this script?" error</h2></p>';
		showFlagHTML += '<p>This report uses JavaScript extensively. If a large dataset is requested, it is common to get the following error:</p>';
		showFlagHTML += '<div style="padding:10px;"><div style="padding:5px;  background-color:#eeeeee;"><p>"A script on this page is causing Internet Explorer to run slowly. If it continues to run, your computer may become unresponsive. Do you want to abort the script?"</p></div></div>';
		showFlagHTML += '<p>To change the IE time-out value, follow the instructions in the <a href="http://support.microsoft.com/kb/175500" target="_blank">How to set time-out period for script</a> Microsoft article.</p>';
		showFlagHTML += '</div></div>';

		showFlagHTML += '<div class="x-panel-body" style="padding:15px;"> ';
		showFlagHTML += '<div style="float:left"><img src="/ext-3.2.0/resources/images/default/shared/warning.gif"></div>';
		showFlagHTML += '<div style="float:left; margin-left:10px;"><p><h2>Internet Explorer is slow</h2></p>';
		showFlagHTML += '<p>This report uses JavaScript extensively. Unfortunately, Internet Explorer is very slow in this regard. Switching to FireFox will increase the processing speed significantly.</p>';
		showFlagHTML += '<p>FireFox can be download from the Mozilla project <a href="http://www.mozilla.com/en-US/products/download.html" target="_blank">here.</a></p>';
		showFlagHTML += '</div></div>';
	}

	if (Ext.isGecko == true)
	{
		showFlag = true;
		isGecko = true;

		showFlagHTML += '<div class="x-panel-body" style="padding:15px;"> ';
		showFlagHTML += '<div style="float:left"><img src="/ext-3.2.0/resources/images/default/shared/warning.gif"></div>';
		showFlagHTML += '<div style="float:left; margin-left:10px;"><p><h2>FireFox script timeout error</h2></p>';
		showFlagHTML += '<p>This report uses JavaScript extensively. If a large dataset is requested, it is possible to get the following error:</p>';
		showFlagHTML += '<div style="padding:10px;"><div style="padding:5px;  background-color:#eeeeee;"><p>"A script is making this page run slow"</p></div></div>';
		showFlagHTML += '<p>To change the FireFox time-out value, and allow the script to run as long as it needs, do the following:</p>';
		showFlagHTML += '<div style="padding:10px;"><div style="padding:5px;  background-color:#eeeeee;"><ul style="padding-left:20px;"><li type=disc>Type <font style="font-size:14; font-family:&quot;Courier New&quot;; font-weight:bold;">about:config</font> in the address bar and press enter</li>';
		showFlagHTML += '<li type=disc>Scroll down or type ahead to find <font style="font-size:14; font-family:&quot;Courier New&quot;; font-weight:bold;">dom.max_script_run_time</font>.</li>';
		showFlagHTML += '<li type=disc>Double click the preference name and type in <font style="font-size:14; font-family:&quot;Courier New&quot;; font-weight:bold;">0</font> seconds as the value (Default could be 5 or 10 seconds).</li>';
		showFlagHTML += '<li type=disc>Restart FireFox.</li>';
		showFlagHTML += '</ul>';
		showFlagHTML += '</div></div>';
		showFlagHTML += '</div></div>';
	}

	// End of requirement testing ----------------------------------------------------------------------------------------------------------------------------------------
			
    var textAreaFixlet = new Ext.form.TextArea({
        id: 'lw-combo',
        // width: 242,
		width: 400,
        // height: 100,
        grow: true,
        growMax: 200,
        renderTo: 'customFixletDiv'
    });

    var textAreaComputer = new Ext.form.TextArea({
        // width: 242,
		width: 400,
        // height: 100,
        grow: true,
        growMax: 200,
        renderTo: 'customComputerDiv'
    });

    document.getElementById('customFixletDiv').style.display = 'none';
    document.getElementById('customComputerDiv').style.display = 'none';

    var currentDay = new Date();
    var oneMonthAgo = new Date().add('mo', -1);
    var twoMonthsAgo = new Date().add('mo', -2);

    var patchTuesdayCurrent = setPeriods(currentDay, 'Begin');
    var patchTuesdayCurrentEnd;
    var patchTuesdayPrevious;
    var patchTuesdayPreviousEnd;
    var patchTuesdayPrevious2;
    var patchTuesdayPrevious2End;

    if (patchTuesdayCurrent > currentDay) {
        currentDay = new Date().add('mo', -1);
        oneMonthAgo = new Date().add('mo', -2);
        twoMonthsAgo = new Date().add('mo', -3);
    }

    patchTuesdayCurrent = setPeriods(currentDay, 'Begin');
    patchTuesdayCurrentEnd = setPeriods(currentDay, 'End');
    patchTuesdayPrevious = setPeriods(oneMonthAgo, 'Begin');
    patchTuesdayPreviousEnd = setPeriods(oneMonthAgo, 'End');
    patchTuesdayPrevious2 = setPeriods(twoMonthsAgo, 'Begin');
    patchTuesdayPrevious2End = setPeriods(twoMonthsAgo, 'End');

    patchTuesdayCurrent = patchTuesdayCurrent.format('d M Y');
    patchTuesdayCurrentEnd = patchTuesdayCurrentEnd.format('d M Y');
    patchTuesdayPrevious = patchTuesdayPrevious.format('d M Y');
    patchTuesdayPreviousEnd = patchTuesdayPreviousEnd.format('d M Y');
    patchTuesdayPrevious2 = patchTuesdayPrevious2.format('d M Y');
    patchTuesdayPrevious2End = patchTuesdayPrevious2End.format('d M Y');

    // Baseline DropList (ComboBox) --------------------------------------------------------------------------------------------------------------------------------------
    // Session Relevance 
	
	// Added by Mark Macherey
	// http://forum.bigfix.com/viewtopic.php?id=5393
	var rel1 = '("C||All Microsoft Critical Fixlets||" & it as string) of number of (bes fixlets whose (fixlet flag of it = true and display name of site of it starts with "Patches for Windows" and source severity of it as lowercase = "critical" and name of it as lowercase does not contain "corrupt patch" and name of it as lowercase does not contain "superseded")); ("I||All Microsoft Important Fixlets||" & it as string) of number of (bes fixlets whose (fixlet flag of it = true and display name of site of it starts with "Patches for Windows" and source severity of it as lowercase = "important" and name of it as lowercase does not contain "corrupt patch" and name of it as lowercase does not contain "superseded")); ("M||All Microsoft Moderate Fixlets||" & it as string) of number of (bes fixlets whose (fixlet flag of it = true and display name of site of it starts with "Patches for Windows" and source severity of it as lowercase = "moderate" and name of it as lowercase does not contain "corrupt patch" and name of it as lowercase does not contain "superseded")); ("L||All Microsoft Low Fixlets||" & it as string) of number of (bes fixlets whose (fixlet flag of it = true and display name of site of it starts with "Patches for Windows" and source severity of it as lowercase = "low" and name of it as lowercase does not contain "corrupt patch" and name of it as lowercase does not contain "superseded")); ("N||All Microsoft None Fixlets||" & it as string) of number of (bes fixlets whose (fixlet flag of it = true and display name of site of it starts with "Patches for Windows" and source severity of it as lowercase = "none" and name of it as lowercase does not contain "corrupt patch" and name of it as lowercase does not contain "superseded")); ("U||All Microsoft Unspecified Fixlets||" & it as string) of number of (bes fixlets whose (fixlet flag of it = true and display name of site of it starts with "Patches for Windows" and source severity of it as lowercase = "<unspecified>" and name of it as lowercase does not contain "corrupt patch" and name of it as lowercase does not contain "superseded")); ("A||Microsoft Patches (Current Period - ' + patchTuesdayCurrent + ')||" & it as string) of number of (bes fixlets whose (fixlet flag of it = true and display name of site of it starts with "Patches for Windows" and name of it as lowercase does not contain "corrupt patch" and name of it as lowercase does not contain "superseded" and source release date of it >= date "' + patchTuesdayCurrent + '" and source release date of it <= date "' + patchTuesdayCurrentEnd + '")); ("D||Microsoft Patches (Previous Period - ' + patchTuesdayPrevious + ')||" & it as string) of number of (bes fixlets whose (fixlet flag of it = true and display name of site of it starts with "Patches for Windows" and name of it as lowercase does not contain "corrupt patch" and name of it as lowercase does not contain "superseded" and source release date of it >= date "' + patchTuesdayPrevious + '" and source release date of it <= date "' + patchTuesdayPreviousEnd + '")); ("E||Microsoft Patches (Previous Period - ' + patchTuesdayPrevious2 + ')||" & it as string) of number of (bes fixlets whose (fixlet flag of it = true and display name of site of it starts with "Patches for Windows" and name of it as lowercase does not contain "corrupt patch" and name of it as lowercase does not contain "superseded" and source release date of it >= date "' + patchTuesdayPrevious2 + '" and source release date of it <= date "' + patchTuesdayPrevious2End + '")); "X||-- Baselines --||0"; unique values of ("B||" & name of it & "||" & number of components of component groups of it as string) of bes fixlets whose (baseline flag of it = true);"X||-- Sites --||0"; ("S||" & it & "||" & multiplicity of it as string) of unique values of display names of sites of bes fixlets whose (fixlet flag of it = true);"X||-- Relevance Expression --||0"; "R||Custom Relevance Expression||0" ';
	
    var res1 = EvaluateRelevance(rel1);
    var contentArray = [];

    for (var i = 0; i < res1.length; i++) {
        var OneRowArray = [];
        OneRowArray = res1[i].split("||");
        // The next if-else statements take care of "label" such as -- Baseline -- 
        // They don't have content count
        if (OneRowArray[0] == "X") {
            OneRowArray[3] = OneRowArray[1];
            OneRowArray[4] = res1[i];
        } else {
            OneRowArray[3] = OneRowArray[1] + " (" + OneRowArray[2] + ")";
            OneRowArray[4] = res1[i];
        }
        contentArray[i] = OneRowArray;
    }

    var storeContent = new Ext.data.ArrayStore({
        fields: ['type', 'name', 'count', 'display', 'full'],
        data: contentArray
    });

    Date.prototype.add = function (sInterval, iNum) {
        var dTemp = this;
        if (!sInterval || iNum == 0) {
            return dTemp;
        }
        switch (sInterval.toLowerCase()) {
        case "ms":
            dTemp.setMilliseconds(dTemp.getMilliseconds() + iNum);
            break;
        case "s":
            dTemp.setSeconds(dTemp.getSeconds() + iNum);
            break;
        case "mi":
            dTemp.setMinutes(dTemp.getMinutes() + iNum);
            break;
        case "h":
            dTemp.setHours(dTemp.getHours() + iNum);
            break;
        case "d":
            dTemp.setDate(dTemp.getDate() + iNum);
            break;
        case "mo":
            dTemp.setMonth(dTemp.getMonth() + iNum);
            break;
        case "y":
            dTemp.setFullYear(dTemp.getFullYear() + iNum);
            break;
        }
        return dTemp;
    };

    function setPeriods(workingDay, choice) {
        if (choice == 'Begin') {
            var today = workingDay;
            var firstOfMonth = new Date(today.getFullYear(), today.getMonth(), 1);
            var firstOfMonthSaved = new Date(today.getFullYear(), today.getMonth(), 1);
            var firstTuesday = firstOfMonth.add('d', (2 - firstOfMonth.getDay()));
            var secondTuesday;

            if (firstTuesday.getTime() < firstOfMonthSaved.getTime()) {
                secondTuesday = firstTuesday.add('d', 14);
            } else {
                secondTuesday = firstTuesday.add('d', 7);
            }
            return secondTuesday;
        }

        if (choice == 'End') {
            var nextMonthToday = workingDay.add('mo', 1);
            var firstOfNextMonth = new Date(nextMonthToday.getFullYear(), nextMonthToday.getMonth(), 1);
            var firstOfNextMonthSaved = new Date(nextMonthToday.getFullYear(), nextMonthToday.getMonth(), 1);
            var firstMondayNextMonth = firstOfNextMonth.add('d', (1 - firstOfNextMonth.getDay()));
            var secondMonday;

            var tempMonday = firstOfNextMonth.add('d', (1 - firstOfNextMonth.getDay()));
            if ((tempMonday.getTime() + (1000 * 60 * 60 * 24)) < firstOfNextMonthSaved.getTime()) {
                secondMonday = firstMondayNextMonth.add('d', 14);
            } else {
                secondMonday = firstMondayNextMonth.add('d', 7);
            }
            return secondMonday;
        }
    }

	comboFromArray1 = new Ext.ux.form.CheckboxCombo({
		applyTo: 'baseline',
		width: 400,
		mode: 'local',
		store: storeContent,
		valueField: 'full',
		displayField: 'display',
        emptyText: 'Select content...',
		allowBlank: false
	});
	
    // Computer Group DropList (ComboBox) ---------------------------------------------------------------------------------------------------------------------------------
    // Session Relevance
    var rel2 = '("All Computers (" & it as string & ")") of number of bes computers; ("All Windows Computers (" & it as string & ")") of number of bes computers whose (operating system of it as lowercase contains "win"); unique values of (name of it & " (" & size of member sets of it as string & ")") of bes computer groups ; "Custom Relevance Expression (0)"';

    var res2 = EvaluateRelevance(rel2);

	comboFromArray2 = new Ext.ux.form.CheckboxCombo({
		applyTo: 'computerGroup',
		width: 400,
		mode: 'local',
		store: res2,
        emptyText: 'Select computer groups...',
		allowBlank: false
	});

    // Populate comboboxes and textareas with info saved in cookies
    var savedFixletComboBox = cp.get('lw-cb-fixlet', 'None');
    var savedComputerComboBox = cp.get('lw-cb-computer', 'None');
    var savedFixletCustom = cp.get('lw-custom-fixlet', 'None');
    var savedComputerCustom = cp.get('lw-custom-computer', 'None');

    if (savedFixletComboBox != 'None') {
        comboFromArray1.setValue(savedFixletComboBox);
    }
    if (savedComputerComboBox != 'None') {
        comboFromArray2.setValue(savedComputerComboBox);
    }
    if (savedFixletCustom != 'None') {
        textAreaFixlet.setValue(savedFixletCustom);
        customFixletText = savedFixletCustom;
    }
    if (savedComputerCustom != 'None') {
        textAreaComputer.setValue(savedComputerCustom);
        customComputerText = savedComputerCustom;
    }

    if (savedFixletComboBox == 'R||Custom Relevance Expression||0') {
        document.getElementById('customFixletDiv').style.display = 'block';
    }

    if (savedComputerComboBox == 'Custom Relevance Expression (0)') {
        document.getElementById('customComputerDiv').style.display = 'block';
    }

    // This function buildGrid is being called by the generateButton -------------------------------------------------------------------------------------------------------

    function buildGrid() {

        var divContent = document.getElementById('content');
        divContent.innerHTML = '';

        var divCompliance = document.getElementById('compliance');
        divCompliance.innerHTML = '';

        var divChart1 = document.getElementById('chart1');
        divChart1.innerHTML = '';

        var divChart2 = document.getElementById('chart2');
        divChart2.innerHTML = '';

        var computerFilter = 'elements of unions of (';

		var computerFilterArray = new Array();
		computerFilterArray = comboFromArray2.value.split(',');
		
        for (var i = 0; i < computerFilterArray.length; i++) {
		
	        var type = computerFilterArray[i].substring(0, 1);

			// Strip the computer count number behind the computer group name
			var computerGroup = computerFilterArray[i].substring(0, computerFilterArray[i].lastIndexOf(' ('));
			
			if (computerGroup == 'All Computers') {
				computerFilter = computerFilter + '(sets of bes computers whose (exists name of it))';
			}
			else if (computerGroup == 'All Windows Computers') {
				computerFilter = computerFilter + '(sets of bes computers whose (exists name of it and operating system of it as lowercase contains "win"))';
			}
			else if (computerGroup == 'Custom Relevance Expression') {
				computerFilter = computerFilter + '(sets of ' + textAreaComputer.getValue() + ')';
			}
			else {
				computerFilter = computerFilter + '(sets of members whose (exists name of it) of bes computer groups whose (name of it = "' + computerGroup + '"))';
			}
			
			if (i == computerFilterArray.length -1)
			{
				// This is the last and closing construct for the relevance statement
				computerFilter = computerFilter + ')';
			}
			else
			{
				// This adds the semicolon to separate the computer sets
				computerFilter = computerFilter + '; ';
			}
		}
		
        // Session Relevance - retrieve computers
        var computerRelevance = 'unique values of (id of it as string & "||" & ("<A name=%22" & name of it & "%22 href=%22" & link href of it & "%22 target=%22_blank%22>" & name of it & "</A>")  & "||" & (if (exists operating system of it) then (operating system of it) else ("Unknown")) & "||" & (if (exists ip addresses of it) then (concatenation ("<br /> ") of (ip addresses of it as string)) else (" ")) & "||" & ((year of it as string & "/" & month of it as two digits & "/" & day_of_month of it as two digits) of  date(local time zone) of it & " "& (two digit hour of it as string & ":" & two digit minute of it as string & ":" & two digit second of it as string) of time (local time zone) of it) of last report time of it) of ' + computerFilter;
        try {
            var computerGroupDataArray = EvaluateRelevance(computerRelevance);
            totalComputers = computerGroupDataArray.length;
        }
        catch(e) {
            if (computerFilter == '' || computerFilter == 'Session Relevance returning Computers') {
                errMsg = '<b>Error:</b> The relevance statement is empty';
            } else {
                errMsg = '<b>Error:</b> ' + e.message + '<br/><br/><b>Statement:</b><br/> ' + computerRelevance;
            }

            Ext.Msg.show({
                title: 'Error in Session Relevance querying for Computers',
                msg: errMsg,
                buttons: Ext.Msg.OK,
                icon: Ext.MessageBox.ERROR,
                minWidth: 350
            });
            Ext.TaskMgr.stopAll();
        }

        var fixletFilter = 'elements of unions of (';

		var fixletFilterArray = new Array();
		fixletFilterArray = comboFromArray1.value.split(',');
		
        for (var i = 0; i < fixletFilterArray.length; i++) {
	        var type = fixletFilterArray[i].substring(0, 1);
    	    var contentName = fixletFilterArray[i].substring(3, fixletFilterArray[i].lastIndexOf("||"));
			
	        if (type == 'B') {
	            fixletFilter = fixletFilter + '(sets of source fixlets of components of component groups of bes fixlets whose (baseline flag of it = true and name of it = "' + contentName + '"))';
	        } else if (type == 'S') {
	            fixletFilter = fixletFilter + '(sets of bes fixlets whose (fixlet flag of it = true and display name of site of it = "' + contentName + '"))';
			} else if (type == 'C') {
				fixletFilter = fixletFilter + '(sets of bes fixlets whose (display name of site of it starts with "Patches for Windows" and source severity of it as lowercase = "critical" and name of it as lowercase does not contain "corrupt patch" and name of it as lowercase does not contain "superseded"))';
			// Following options added by Mark Marcherey http://forum.bigfix.com/viewtopic.php?id=5393	
			} else if (type == 'I') {
				fixletFilter = fixletFilter + '(sets of bes fixlets whose (display name of site of it starts with "Patches for Windows" and source severity of it as lowercase = "important" and name of it as lowercase does not contain "corrupt patch" and name of it as lowercase does not contain "superseded"))';
			} else if (type == 'M') {
				fixletFilter = fixletFilter + '(sets of bes fixlets whose (display name of site of it starts with "Patches for Windows" and source severity of it as lowercase = "moderate" and name of it as lowercase does not contain "corrupt patch" and name of it as lowercase does not contain "superseded"))';
			} else if (type == 'L') {
				fixletFilter = fixletFilter + '(sets of bes fixlets whose (display name of site of it starts with "Patches for Windows" and source severity of it as lowercase = "low" and name of it as lowercase does not contain "corrupt patch" and name of it as lowercase does not contain "superseded"))';
			} else if (type == 'N') {
				fixletFilter = fixletFilter + '(sets of bes fixlets whose (display name of site of it starts with "Patches for Windows" and source severity of it as lowercase = "none" and name of it as lowercase does not contain "corrupt patch" and name of it as lowercase does not contain "superseded"))';
			} else if (type == 'U') {
				fixletFilter = fixletFilter + '(sets of bes fixlets whose (display name of site of it starts with "Patches for Windows" and source severity of it as lowercase = "<unspecified>" and name of it as lowercase does not contain "corrupt patch" and name of it as lowercase does not contain "superseded"))';	        
			} else if (type == 'R') {
	            fixletFilter = fixletFilter + '(sets of ' + textAreaFixlet.getValue() + ')';
	        } else if (type == 'A') {
	            fixletFilter = fixletFilter + '(sets of bes fixlets whose (fixlet flag of it = true and display name of site of it starts with "Patches for Windows" and name of it as lowercase does not contain "corrupt patch" and name of it as lowercase does not contain "superseded" and source release date of it >= date "' + patchTuesdayCurrent + '" and source release date of it <= date "' + patchTuesdayCurrentEnd + '"))';
	        } else if (type == 'D') {
	            fixletFilter = fixletFilter + '(sets of bes fixlets whose (fixlet flag of it = true and display name of site of it starts with "Patches for Windows" and name of it as lowercase does not contain "corrupt patch" and name of it as lowercase does not contain "superseded" and source release date of it >= date "' + patchTuesdayPrevious + '" and source release date of it <= date "' + patchTuesdayPreviousEnd + '"))';
	        } else if (type == 'E') {
	            fixletFilter = fixletFilter + '(sets of bes fixlets whose (fixlet flag of it = true and display name of site of it starts with "Patches for Windows" and name of it as lowercase does not contain "corrupt patch" and name of it as lowercase does not contain "superseded" and source release date of it >= date "' + patchTuesdayPrevious2 + '" and source release date of it <= date "' + patchTuesdayPrevious2End + '"))';
	        }
			
			if (i == fixletFilterArray.length -1)
			{
				// This is the last and closing construct for the relevance statement
				fixletFilter = fixletFilter + ')';
			}
			else if (type != 'X')
			{
				// This adds the semicolon to separate the Fixlet sets
				fixletFilter = fixletFilter + '; ';
			}
		}
		
        // Session Relevance - retrieve Fixlets
        var relevance = 'unique values of (id of item 0 of it as string & "||" & name of item 0 of it & "||" & item 1 of it & "||" & item 2 of it & "||" & item 3 of it & "||" & item 4 of it & "||" & item 5 of it & "||" & item 6 of it & "||" & item 7 of it) of (applicable computers whose (exists name of it) of it, ("<A name=%22" & name of it & "%22 href=%22" & link href of it & "%22 target=%22_blank%22>" & name of it & "</A>"), (if (exists source severity of it) then ( if (source severity of it as lowercase contains "<unspecified>" or source severity of it as lowercase contains "<n/a>") then ("Unspecified") else (source severity of it) ) else ("Unspecified")), (if (exists source release date of it ) then ((year of it as string & "-" & month of it as two digits as string & "-" & day_of_month of it as two digits as string) of source release date of it as string) else "1000-01-01"), (if (exists category of it) then (if (category of it as lowercase contains "<unspecified>") then ("Unspecified") else (category of it as string) ) else ("Unknown")), (if (exists download size of it) then ((download size of it) as string) else ("0")),display name of site of it, applicable computer count of it as string) of ' + fixletFilter;

        try {
            var res = EvaluateRelevance(relevance);
        }
        catch(e) {
            if (fixletFilter == '' || fixletFilter == 'Session Relevance returning Fixlets') {
                errMsg = '<b>Error:</b> The relevance statement is empty';
            } else {
                errMsg = '<b>Error:</b> ' + e.message + '<br/><br/><b>Statement:</b><br/> ' + relevance;
            }

            Ext.Msg.show({
                title: 'Error in Session Relevance querying for Fixlets',
                msg: errMsg,
                buttons: Ext.Msg.OK,
                icon: Ext.MessageBox.ERROR,
                minWidth: 350
            });
            Ext.TaskMgr.stopAll();

        }
        var outstandingFixletsArray = [];
        // var outstandingFixletsArrayComplete = [];
        var memoryProxy = new Ext.data.MemoryProxy(outstandingFixletsArray);

        myChartData = [];
        var cnt = -1;
        var chartData = [];
        var currentName = 'XXX';
        var currentCount = -1;
        var uniqueCount = -1;
        var computerID = '';
        var found = false;

        // ========================================================================================================
        var currentComputerIDinRes = 0;
        var computerArray = computerGroupDataArray.slice();

        for (var i = 0; i < res.length; i++) {

            var dataArray = res[i].split("||");

            if (currentComputerIDinRes != dataArray[0] && currentComputerIDinRes != 0 && found == true) {
                computerArray = computerArray.slice(1);
                found = false;
            }

            for (var j = 0; j < computerArray.length; j++) {
                computerID = computerArray[j].substring(0, computerArray[j].indexOf('||'));
                // Find out if the Fixlet is for a computer in the selected group
                if (computerID == dataArray[0]) {

                    found = true;
                    // Charting data
                    if (dataArray[1] != currentName) {
                        currentName = dataArray[1];

                        var chartData = [];

                        currentCount = 0;
                        if (currentName != 'XXX') {
                            currentCount++;
                            uniqueCount++;
                            myChartData[uniqueCount] = chartData;
                        }

                        chartData[1] = dataArray[1];
                        chartData[0] = currentCount++;
                    } else {
                        chartData[0] = currentCount++;
                    } // end charting data
                    cnt++;
                    outstandingFixletsArray[cnt] = dataArray;
                    break;
                }
            }
            currentComputerIDinRes = dataArray[0];
        }

        // ======================================================================================================== */
        // Slice array if too much data
        totalRelevantFixlets = outstandingFixletsArray.length;
        if (outstandingFixletsArray.length > diplayedRelevantFixlets) {
            // info('There is too much data returned (' + addCommas(outstandingFixletsArray.length.toString()) + ' items), only the first 1000 will be displayed in the bottom grid.', 4000);
            /*
            Ext.Msg.show({
                title: 'Warning',
                msg: 'There is too much data returned (' + outstandingFixletsArray.length + ' items), only the first -diplayedRelevantFixlets- will be displayed in the grid',
                buttons: Ext.Msg.OK,
                icon: Ext.MessageBox.WARNING,
                minWidth: 300
            }); */

            outstandingFixletsArray = outstandingFixletsArray.sort(sortByName);
            outstandingFixletsArray = outstandingFixletsArray.slice(0, diplayedRelevantFixlets);
        }

        function sortByName(a, b) {
            var x = a[1];
            var y = b[1];
            return x == y ? 0 : (x < y ? -1 : 1)
        }

        xg.dummyData = outstandingFixletsArray;

        var reader = new Ext.data.ArrayReader({},
        [{
            name: 'ComputerID'
        },
        {
            name: 'ComputerName'
        },
        {
            name: 'FixletName'
        },
        {
            name: 'SourceSeverity'
        },
        {
            name: 'SourceReleaseDate',
            type: 'date',
            dateFormat: 'Y-m-d'
        },
        {
            name: 'Category'
        },
        {
            name: 'DownloadSize',
            type: 'int'
        },
        {
            name: 'SiteName'
        },
        {
            name: 'ApplicableComputerCount',
            type: 'int'
        }]);

        var gStore = new Ext.data.GroupingStore({
            reader: reader,
            data: xg.dummyData,
            proxy: memoryProxy,
            sortInfo: {
                field: 'FixletName',
                direction: "ASC"
            },
            autoLoad: true,
            groupField: 'ComputerName'
        });

        var gpView = new Ext.grid.GroupingView({
            autoFill: true,
            deferEmptyText: 'Loading...',
            forceFit: true,
            groupTextTpl: '{text}  ({[values.rs.length]} {[values.rs.length > 1 ? "Items" : "Item"]})'
        });



        function severityColor(val) {
            if (val.toLowerCase() == "critical" || val.toLowerCase() == "high" || val.toLowerCase() == "critical fixes" || val.toLowerCase() == "high impact/highly pervasive") {
                return '<span style="color:red;">' + val + '</span>';
            } else if (val.toLowerCase() == "important" || val.toLowerCase() == "medium") {
                return '<span style="color:orange;">' + val + '</span>';
            } else if (val.toLowerCase() == "moderate" || val.toLowerCase() == "security advisory") {
                return '<span style="color:blue;">' + val + '</span>';
            } else if (val.toLowerCase() == "low") {
                return '<span style="color:green;">' + val + '</span>';
            }

            return val;
        }



        function complianceColor(val) {
            if (val >= 90) {
                return '<span style="color:#008800;"><b>' + val.toFixed(2) + '%</b></span>';
            } else if (val >= 70 && val < 90) {
                return '<span style="color:#15428b;"><b>' + val.toFixed(2) + '%</b></span>';
            } else if (val <= 20 && val >= 0) {
                return '<span style="color:#cc3333;"><b>' + val.toFixed(2) + '%</b></span>';
            } else if (val == -99) {
                return '<span style="color:#15428b;"><b>--</b></span>';
            } else {
                return '<span style="color:orange;"><b>' + val.toFixed(2) + '%</b></span>';
            }
        }

        function complianceColorForExport(val) {
            if (val == -99) {
                return '-';
            } else {
                return val.toFixed(2);
            }
        }


        function sourceReleaseDateFormat(val) {
            var tempDate = new Date(1000, 0, 1);
            if (val.getTime() == tempDate.getTime()) {
                return '<span>--</span>';
            } else {
                return '<span>' + Ext.util.Format.date(val, 'Y/m/d (D)') + '</span>';
            }
        }

        var pStore2 = new Ext.data.ArrayStore({
            fields: [{
                name: 'ComputerID'
            },
            {
                name: 'ComputerName'
            },
            {
                name: 'OperatingSystem'
            },
            {
                name: 'IPAddress'
            },
            {
                name: 'LastReportTime'
            },
            {
                name: 'ApplicableFixlets',
                type: 'int'
            },
            {
                name: 'InstalledFixlets',
                type: 'int'
            },
            {
                name: 'OutstandingFixlets',
                type: 'int'
            },
            {
                name: 'Compliance',
                type: 'float'
            }]
        });

        var pStore = new Ext.ux.data.PagingArrayStore({
            fields: [{
                name: 'ComputerID'
            },
            {
                name: 'ComputerName'
            },
            {
                name: 'OperatingSystem'
            },
            {
                name: 'IPAddress'
            },
            {
                name: 'LastReportTime'
            },
            {
                name: 'ApplicableFixlets',
                type: 'int'
            },
            {
                name: 'InstalledFixlets',
                type: 'int'
            },
            {
                name: 'OutstandingFixlets',
                type: 'int'
            },
            {
                name: 'Compliance',
                type: 'float'
            }],
            lastOptions: {
                params: {
                    start: 0,
                    limit: 20
                }
            }
        });

        // Session Relevance
        var relevanceCompliance = '(id of computer of it as string & "||" & (if (exists last became relevant of it) then (1) else (0)) as string & "||" & (if (exists last became nonrelevant of it and relevant flag of it = false) then (1) else (0) ) as string & "||" & (if (relevant flag of it = true) then (1) else (0) ) as string) of results of ' + fixletFilter;

		// alert (relevanceCompliance);

        var resultsCompliance = EvaluateRelevance(relevanceCompliance);

        var dataComplianceArray = [];
        var dataComplianceArrayMinus = [];

        for (var i = 0; i < computerGroupDataArray.length; i++) {
            dataComplianceArray[i] = computerGroupDataArray[i].split('||');
            dataComplianceArray[i][5] = 0;
            dataComplianceArray[i][6] = 0;
            dataComplianceArray[i][7] = 0;
            dataComplianceArray[i][8] = valueForZeroApplicable;
        }

        var dataComplianceOneRow = [];

        for (var i = 0; i < resultsCompliance.length; i++) {

            dataComplianceOneRow = resultsCompliance[i].split('||');

            for (var j = 0; j < dataComplianceArray.length; j++) {
                if (dataComplianceOneRow[0] == dataComplianceArray[j][0]) {
                    // Index 5 are Applicable Fixlets
                    dataComplianceArray[j][5] = (parseInt(dataComplianceArray[j][5]) + parseInt(dataComplianceOneRow[1])).toString();

                    // Index 6 are Installed Fixlets
                    dataComplianceArray[j][6] = (parseInt(dataComplianceArray[j][6]) + parseInt(dataComplianceOneRow[2])).toString();

                    // Index 7 are Outstanding Fixlets
                    dataComplianceArray[j][7] = (parseInt(dataComplianceArray[j][7]) + parseInt(dataComplianceOneRow[3])).toString();

                    // Index 8 are Compliance Percentages
                    if (dataComplianceArray[j][5] != 0) {
                        dataComplianceArray[j][8] = ((parseFloat(dataComplianceArray[j][6]) / parseFloat(dataComplianceArray[j][5])) * 100).toFixed(2);
                    }
                    break;
                }
            }
        }

        // manually load local data
        pStore.loadData(dataComplianceArray);

        totalApplicableFixlets = sumIndex(dataComplianceArray, 5);
        totalInstalledFixlets = sumIndex(dataComplianceArray, 6);
        totalOutstandingFixlets = sumIndex(dataComplianceArray, 7);
        if (totalApplicableFixlets == 0) {
            compliancePercentage = 100;
        } else {
            compliancePercentage = (parseFloat(totalInstalledFixlets) / parseFloat(totalApplicableFixlets) * 100).toFixed(2);
        }

        if (compliancePercentage >= 90) {
            complianceHTML = '<h1 style="margin-bottom: 5px"><font size="4" color="#008800"><center>' + compliancePercentage + '% Compliant</center></font></h1>';
        } else if (compliancePercentage >= 70 && compliancePercentage < 90) {
            complianceHTML = '<h1 style="margin-bottom: 5px"><font size="4" color="orange"><center>' + compliancePercentage + '% Compliant</center></font></h1>';
        } else if (compliancePercentage <= 20) {
            complianceHTML = '<h1 style="margin-bottom: 5px"><font size="4" color="#cc3333"><center>' + compliancePercentage + '% Compliant</center></font></h1>';
        } else {
            complianceHTML = '<h1 style="margin-bottom: 5px"><font size="4" color="#15428b"><center>' + compliancePercentage + '% Compliant</center></font></h1>';
        }

        complianceLegendHTML = '';
        complianceLegendHTML += '<center><table style="margin-top: 6px;" border="0"><tr><td><img src="/ext-3.2.0/resources/images/default/lw/green.png" alt="Installed" /></td><td style="font:bold 10px tahoma,arial,verdana,sans-serif; color:#15428b;">&nbsp;&nbsp;Installed:</td><td style="font:bold 10px tahoma,arial,verdana,sans-serif; color:#15428b;" align="right">';
        complianceLegendHTML += addCommas(totalInstalledFixlets);
        complianceLegendHTML += '</td></tr><tr><td><img src="/ext-3.2.0/resources/images/default/lw/red.png" alt="Outstanding" /></td><td style="font:bold 10px tahoma,arial,verdana,sans-serif; color:#15428b;">&nbsp;&nbsp;Outstanding:&nbsp;&nbsp;</td><td style="font:bold 10px tahoma,arial,verdana,sans-serif; color:#15428b;" align="right">';
        complianceLegendHTML += addCommas(totalOutstandingFixlets);
        complianceLegendHTML += '</td></tr></table></center>';



        function sumIndex(arr, index) {
            var sum = 0;

            for (var i = 0; i < arr.length; i++) {
                if (!isNaN(arr[i][index])) sum += parseInt(arr[i][index]);
            }
            return sum;
        }

        // create the Grid
        var gridCompliance = new Ext.grid.GridPanel({
            iconCls: 'icon-compliance',
            store: pStore,
            columns: [{
                id: 'ComputerID',
                header: 'Computer ID',
                sortable: true,
                width: 100,
                dataIndex: 'ComputerID',
                hidden: true
            },
            {
                header: 'Computer',
                sortable: true,
                width: 140,
                dataIndex: 'ComputerName'
            },
            {
                header: 'Operating System',
                sortable: true,
                width: 140,
                dataIndex: 'OperatingSystem'
            },
            {
                header: 'IP Address',
                sortable: true,
                width: 135,
                dataIndex: 'IPAddress'
            },
            {
                header: 'Last Report Time',
                sortable: true,
                width: 135,
                dataIndex: 'LastReportTime'
            },
            {
                header: 'Applicable Fixlets',
                sortable: true,
                width: 110,
                align: 'right',
                tooltip: '<b>Applicable Fixlets</b><br/>Fixlets that are relevant at some point<br/>Installed plus Outstanding always add up to Applicable',
                dataIndex: 'ApplicableFixlets'
            },
            {
                header: 'Installed Fixlets',
                sortable: true,
                width: 110,
                align: 'right',
                tooltip: '<b>Installed Fixlets</b><br/>Remediated and no longer relevant',
                dataIndex: 'InstalledFixlets'
            },
            {
                header: 'Outstanding Fixlets',
                sortable: true,
                width: 110,
                align: 'right',
                tooltip: '<b>Outstanding Fixlets</b><br/>Fixlets that are still relevant',
                dataIndex: 'OutstandingFixlets'
            },
            {
                header: 'Compliance',
                sortable: true,
                width: 110,
                align: 'right',
                tooltip: '<b>Compliance Percentage</b><br/>Compliance is calculated by:<br/>Installed / Applicable',
                dataIndex: 'Compliance',
                renderer: complianceColor
            }],
            stripeRows: true,
            //autoExpandMin: 100,
            // autoHeight: true,
            height: 580,
            width: 1000,
            // columnLines: true,
            title: 'Compliance by Computers',
            collapsible: true,
            animCollapse: false,
            renderTo: 'compliance',
            // config options for stateful behavior
            stateful: true,
            stateId: 'grid',

            // paging bar on the bottom
            bbar: new Ext.PagingToolbar({
                pageSize: 20,
                store: pStore,
                displayInfo: true,
                displayMsg: 'Displaying computers {0} - {1} of {2}',
                emptyMsg: "No computers to display"
            }),
            tbar: new Ext.Toolbar({
                items: [{
                    xtype: 'tbfill'
                },
                {
                    xtype: 'tbseparator'
                },
                {
                    xtype: 'tbtext',
                    text: 'Hide Computers with 0 Applicable Fixlets '
                },
                {
                    xtype: 'checkbox',
                    id: 'checkBoxShowAll',
                    name: 'checkBoxShowAll',
                    handler: function () {
                        var hideComputers;
                        hideComputers = Ext.getCmp('checkBoxShowAll').getValue();

                        if (hideComputers) {
                            if (dataComplianceArrayMinus.length == 0) {
                                for (var i = 0; i < dataComplianceArray.length; i++) {
                                    // Index 5 is applicable fixlet count
                                    if (dataComplianceArray[i][5] > 0) {
                                        dataComplianceArrayMinus.push(dataComplianceArray[i]);
                                    }
                                }
                            }
                            pStore.loadData(dataComplianceArrayMinus);
					        gridCompliance.setTitle('Compliance for - ' + computerGroup + ' by ' + contentName + ': (' + dataComplianceArrayMinus.length + ' total items)');

                        } else {
                            pStore.loadData(dataComplianceArray);
					        gridCompliance.setTitle('Compliance for - ' + computerGroup + ' by ' + contentName + ': (' + dataComplianceArray.length + ' total items)');

                        }
                    }
                },
                {
                    xtype: 'tbseparator'
                },
                {
                    xtype: 'tbbutton',
                    iconCls: 'icon-print',
                    text: 'Print',
                    scale: 'small',
                    handler: function () {
                        var hideComputers;
                        hideComputers = Ext.getCmp('checkBoxShowAll').getValue();

                        if (hideComputers) {
                            pStore2.loadData(dataComplianceArrayMinus);
                        } else {
                            pStore2.loadData(dataComplianceArray);
                        }

                        // If the data has been sorted via clicking the column headings, do the same for the data to be printed
                        if (pStore.sortInfo != null) {
                            pStore2.sort(pStore.sortInfo.field, pStore.sortInfo.direction);
                        }
                        var newColumnModel = gridCompliance.getColumnModel();
                        gridCompliance.reconfigure(pStore2, newColumnModel);
                        Ext.ux.Printer.print(gridCompliance);
                        gridCompliance.reconfigure(pStore, newColumnModel);

                    }
                },
                {
                    xtype: 'tbseparator'
                },
                {
                    xtype: 'tbbutton',
                    iconCls: 'icon-excel',
                    text: 'Excel',
                    scale: 'small',
                    handler: function () {

						if (Ext.isGecko == false && Ext.isSafari == false)
						{
			                Ext.Msg.show({
			                    title: 'Sorry!',
			                    msg: 'The export to Excel function is only available in FireFox or Safari',
			                    buttons: Ext.Msg.OK,
			                    icon: Ext.MessageBox.INFO,
			                    minWidth: 300
			                });
							return;
						}

                        info('Generating data for Excel...', 2000, 'compliance', -400);

                        document.getElementById('footer').innerHTML = '';


                        var hideComputers;
                        hideComputers = Ext.getCmp('checkBoxShowAll').getValue();

                        if (hideComputers) {
                            pStore2.loadData(dataComplianceArrayMinus);
                        } else {
                            pStore2.loadData(dataComplianceArray);
                        }

                        // If the data has been sorted via clicking the column headings, do the same for the data to be printed
                        if (pStore.sortInfo != null) {
                            pStore2.sort(pStore.sortInfo.field, pStore.sortInfo.direction);
                        }

                        var newColumnModel = gridCompliance.getColumnModel();
                        // For the purpose of exporting, we have expanded the grid with full data
                        gridCompliance.reconfigure(pStore2, newColumnModel);
						// Column index 8 is the compliance percentage column, the following gets rid of the '%' sign before export
						newColumnModel.setRenderer(8, complianceColorForExport);

                        var exportButton = new Ext.ux.Exporter.Button({
                            name: 'excelLinkButton',
                            id: 'excelLinkButton',
                            text: '.',
                            component: gridCompliance,
                            renderTo: 'footer',
                            store: pStore2
                        });
                        // This is a very convoluted way of doing Excel export
                        // The library that I use puts the functionality in a button.
                        // However, the buttons needs to be dynamically generated to associate 
                        // the latest set of data.				        
                        // window.open(exportButton.getEl().child('a', true).href, "name");
                        window.location.href = exportButton.getEl().child('a', true).href;

                        // Put the grid back to its original state with paging
						newColumnModel.setRenderer(8, complianceColor);
                        gridCompliance.reconfigure(pStore, newColumnModel);
                    }
                },
                {
                    xtype: 'tbseparator'
                }]
            })
        });

        gridCompliance.setTitle('Compliance for - ' + computerGroup + ' by ' + contentName + ': (' + totalComputers + ' total items)');

        // Disable the superflous Refresh button for the PagingToolbar
        gridCompliance.getBottomToolbar().refresh.hideParent = true;
        gridCompliance.getBottomToolbar().refresh.hide();
		
		gridCompliance.getEl().mask('Loading...', 'x-mask-loading');
        pStore.loadData(dataComplianceArray);

		gridCompliance.getEl().unmask();


        // Vulnerability GridPanel ---------------------------------------------------------------------------------------------------------------------------------------------------------------    
        var grid = new xg.GridPanel({
            store: gStore,

            columns: [{
                header: "Fixlet Name",
                width: 80,
                sortable: true,
                dataIndex: 'FixletName'
            },
            {
                header: "Computer",
                width: 20,
                sortable: true,
                dataIndex: 'ComputerName'
            },
            {
                header: "Source Severity",
                width: 20,
                sortable: true,
                dataIndex: 'SourceSeverity',
                renderer: severityColor
            },
            {
                header: "Category",
                width: 20,
                sortable: true,
                dataIndex: 'Category'
            },
            {
                header: "Source Release Date",
                width: 25,
                sortable: true,
                renderer: sourceReleaseDateFormat,
                dataIndex: 'SourceReleaseDate'
            },
            {
                header: "Download Size",
                width: 20,
                sortable: true,
                renderer: Ext.util.Format.fileSize,
                dataIndex: 'DownloadSize',
                align: 'right'
            },
            {
                header: "Site Name",
                width: 30,
                sortable: true,
                dataIndex: 'SiteName'
            },
            {
                header: "Applicable Computer Count",
                width: 20,
                sortable: true,
                dataIndex: 'ApplicableComputerCount',
                align: 'right',
                hidden: true
            }],
            view: gpView,
            columnLines: true,
            frame: true,
            width: 1000,
            height: 500,
            collapsible: true,
            animCollapse: false,
            title: 'Relevant Fixlets',
            iconCls: 'icon-grid',
            renderTo: 'content',
            loadMask: {
                msg: 'Loading data, please wait...'
            },
            tbar: new Ext.Toolbar({
                items: [{
                    xtype: 'tbfill'
                },
                {
                    xtype: 'tbseparator'
                },
                {
                    xtype: 'tbbutton',
                    iconCls: 'icon-expand',
                    text: 'Expand Data',
                    scale: 'small',
                    handler: function () {
                        gpView.expandAllGroups();
                    }
                },
                {
                    xtype: 'tbseparator'
                },
                {
                    xtype: 'tbbutton',
                    iconCls: 'icon-collapse',
                    text: 'Collapse Data',
                    scale: 'small',
                    handler: function () {
                        gpView.collapseAllGroups();
                    }
                },
                {
                    xtype: 'tbseparator'
                },
                {
                    xtype: 'tbbutton',
                    iconCls: 'icon-print',
                    text: 'Print',
                    scale: 'small',
                    handler: function () {
                        Ext.ux.Printer.print(grid);
                    }
                },
                {
                    xtype: 'tbseparator'
                },
                {
                    xtype: 'tbbutton',
                    iconCls: 'icon-excel',
                    text: 'Excel',
                    scale: 'small',
                    handler: function () {

						if (Ext.isGecko == false && Ext.isSafari == false)
						{
			                Ext.Msg.show({
			                    title: 'Sorry!',
			                    msg: 'The export to Excel function is only available in FireFox or Safari',
			                    buttons: Ext.Msg.OK,
			                    icon: Ext.MessageBox.INFO,
			                    minWidth: 300
			                });
							return;
						} 
						
                        info('Generating data for Excel...', 2000, 'content', -400);

                        document.getElementById('footer').innerHTML = '';

                        var exportButton2 = new Ext.ux.Exporter.Button({
                            name: 'excelLinkButton',
                            id: 'excelLinkButton',
                            text: '.',
                            component: grid,
                            renderTo: 'footer',
                            store: gStore
                        });
                        // This is a very convoluted way of doing Excel export
                        // The library that I use puts the functionality in a button.
                        // However, the buttons needs to be dynamically generated to associate 
                        // the latest set of data.				        
                        // window.open(exportButton.getEl().child('a', true).href, "name");
                        window.location.href = exportButton2.getEl().child('a', true).href;
                    }
                },
                {
                    xtype: 'tbseparator'
                }]
            })
        }); // End Vulnerability Grid panel
        
        // myMask.hide();

        if (totalRelevantFixlets > grid.getStore().getCount()) {
            grid.setTitle('Outstanding Fixlets for - ' + computerGroup + ' by ' + contentName + ': (' + totalRelevantFixlets + ' total items, ' + grid.getStore().getCount() + ' displayed)');
        } else {
            grid.setTitle('Outstanding Fixlets for - ' + computerGroup + ' by ' + contentName + ': (' + grid.getStore().getCount() + ' total items)');
        }

    } // End buildGrid function

    // Charting ------------------------------------------------------------------------------------------------------------------------------------------------------------

    function buildChart() {

        var divChart1 = document.getElementById('chart1');
        divChart1.innerHTML = '';

        var divChart2 = document.getElementById('chart2');
        divChart2.innerHTML = '';

        var storeChart = new Ext.data.ArrayStore({
            fields: [{
                name: 'patches',
                type: 'float'
            },
            {
                name: 'name'
            }],
            sortInfo: {
                field: 'patches',
                direction: 'DESC'
            }
        });



        function sortByPatches(a, b) {
            var x = a[0];
            var y = b[0];
            return x == y ? 0 : (x < y ? 1 : -1)
        }



        function mySorting(a, b) {
            a = a[0];
            b = b[0];
            return a == b ? 0 : (a < b ? 1 : -1)
        }

        // Sorts the array in reverse order. Function is needed for numerical values
        myChartData.sort(sortByPatches);
        var topNumOfVulnerableComputers = 0;
        if (myChartData.length <= 15) {
            storeChart.loadData(myChartData);
            topNumOfVulnerableComputers = myChartData.length;
        } else {
            storeChart.loadData(myChartData.slice(0, 15));
            topNumOfVulnerableComputers = 15;
        }
		
        new Ext.Panel({
            iconCls: 'chart-bar',
            title: topNumOfVulnerableComputers + ' Most Vulnerable Computers',
            frame: true,
            renderTo: 'chart2',
            collapsible: true,
            animCollapse: false,
            width: 788,
            height: 300,
            layout: 'anchor',

            items: [{
                region: 'west',
                xtype: 'columnchart',
                store: storeChart,
                url: '/ext-3.2.0/resources/charts.swf',
                xField: 'name',
                yAxis: new Ext.chart.NumericAxis({
                    title: 'Number of Relevant Fixlets',
                    displayName: 'Patches',
                    alwaysShowZero: true,
                    labelRenderer: Ext.util.Format.numberRenderer('0,0'),
                    majorUnit: 5,
                    minorUnit: 1
                }),
                tipRenderer: function (chart, record, index, series) {
                    if (series.yField == 'patches') {
                        if (record.data.patches == 1) {
                            return Ext.util.Format.number(record.data.patches, '0,0') + ' patch for ' + record.data.name;
                        } else {
                            return Ext.util.Format.number(record.data.patches, '0,0') + ' patches for ' + record.data.name;
                        }
                    }
                },
                chartStyle: {
                    padding: 10,
                    animationEnabled: true,
                    font: {
                        name: 'Tahoma',
                        color: 0x444444,
                        size: 11
                    },
                    dataTip: {
                        padding: 5,
                        border: {
                            color: 0x99bbe8,
                            size: 1
                        },
                        background: {
                            color: 0xDAE7F6,
                            alpha: .9
                        },
                        font: {
                            name: 'Tahoma',
                            color: 0x15428B,
                            size: 10,
                            bold: true
                        }
                    },
                    xAxis: {
                        color: 0x69aBc8,
                        labelRotation: 75,
                        majorTicks: {
                            color: 0x69aBc8,
                            length: 4
                        },
                        minorTicks: {
                            color: 0x69aBc8,
                            length: 2
                        },
                        majorGridLines: {
                            size: 1,
                            color: 0xeeeeee
                        }
                    },
                    yAxis: {
                        titleRotation: -90,
                        color: 0x69aBc8,
                        majorTicks: {
                            color: 0x69aBc8,
                            length: 4
                        },
                        minorTicks: {
                            color: 0x69aBc8,
                            length: 2
                        },
                        majorGridLines: {
                            size: 1,
                            color: 0xdfe8f6
                        }
                    }
                },
                series: [{
                    type: 'column',
                    yField: 'patches',
                    style: {
                        image: '/ext-3.2.0/resources/images/default/lw/red-bar.gif',
                        mode: 'stretch',
                        color: 0xE77471
                    }
                }]
            }]
        }); // Chart panel 1
        
        if (totalApplicableFixlets == 0) {
            var storeChart = new Ext.data.JsonStore({
                fields: ['fixletcount', 'total'],
                data: [{
                    fixletcount: 'Installed',
                    total: totalInstalledFixlets
                }]
            });
        } else {
            var storeChart = new Ext.data.JsonStore({
                fields: ['fixletcount', 'total'],
                data: [{
                    fixletcount: 'Installed',
                    total: totalInstalledFixlets
                },
                {
                    fixletcount: 'Outstanding',
                    total: totalOutstandingFixlets
                }]
            });
        }

        new Ext.Panel({
            iconCls: 'chart-pie',
            frame: true,
            width: 200,
            height: 300,
            title: 'Compliance Summary',
            collapsible: true,
            animCollapse: false,
            renderTo: 'chart1',
            items: [{
                html: complianceHTML
            },
            {
                store: storeChart,
                xtype: 'piechart',
                url: '/ext-3.2.0/resources/charts.swf',
                dataField: 'total',
                height: 200,
                bottom: 50,
                categoryField: 'fixletcount',
                series: [{
                    // Green: 0x008800, 
                    // Red: 0xcc3333
                    style: {
                        colors: [0x008800, 0xcc3333]
                    }
                }]
            },
            {
                html: complianceLegendHTML
            }]
        }); // Chart panel 2
    } // Build grid

    function info(msg, timeout, div, offsetY) {
        new Ext.ux.window.MessageWindow({
            title: 'Message:',
            html: msg || 'No information available',
            origin: {
                el: Ext.get(div),
                //element to align to 
                offX: -0.5 * Ext.get(div).getWidth(),
                //amount to offset horizontally
                offY: offsetY
            },
            autoHeight: true,
            pinOnClick: false,
            iconCls: 'icon-info',
            help: false,
            hideFx: {
                delay: timeout,
                mode: 'standard'
            }
        }).show(Ext.getDoc());
    } //function info()

    function addCommas(nStr) {
        nStr += '';
        x = nStr.split('.');
        x1 = x[0];
        x2 = x.length > 1 ? '.' + x[1] : '';
        var rgx = /(\d+)(\d{3})/;
        while (rgx.test(x1)) {
            x1 = x1.replace(rgx, '$1' + ',' + '$2');
        }
        return x1 + x2;
    }

    //finally, remove the loading mask
    (function () {
        Ext.get('loading').remove();
        Ext.get('loading-mask').fadeOut({
            remove: true
        });
    }).defer(250);

}); // onReady

// Timer code:
// startTime=new Date().getTime();
// endTime=new Date().getTime();
// alert(addCommas(howMany) + ' Elapsed time for res: '+((endTime-startTime)/1000)+' seconds.');